# Asset & Design Licenses

## Overview
This document outlines the licensing, copyright, and provenance for all assets contained within the `Yogendra630` animated GitHub Profile README suite.

---

### 1. Vector Illustrations & Character Assets
- **`assets/id.png`**
  - **Type:** Illustrated Character Portrait (Chest-upward)
  - **Subject:** Yogendra Maurya
  - **License:** Permissive Custom Open Source License / Personal Developer License for Yogendra Maurya. Free to use, adapt, and distribute for personal branding, resumes, and portfolios.
- **`assets/right_pointing.png`**
  - **Type:** Illustrated Character Gesture (Waist-upward, pointing rightward)
  - **Subject:** Yogendra Maurya
  - **License:** Permissive Custom Open Source License / Personal Developer License for Yogendra Maurya.

---

### 2. Animated SVG Files
- **`assets/hero.svg`**
- **`assets/about-life.svg`**
- **`assets/stack.svg`**
- **`assets/id-dashboard.svg`**
- **`assets/connect.svg`**
  - **Author:** Handcrafted modular SVG suite with pure CSS keyframe animations.
  - **Dependencies:** Self-contained SVG elements. No external scripts or foreignObjects.
  - **License:** MIT License. Free to modify, inspect, and deploy.

---

### 3. Typography & System Fonts
- All SVGs employ standard cross-platform system font stacks (`ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif`).
- No commercial proprietary font files are embedded or required.

---

### 4. Brand Icons & Logos
- Technology labels (Java, Python, Spring Boot, React, MySQL, AWS, etc.) refer to their respective open-source projects or registered trademarks.
- Mentioned strictly under nominative fair use for technical skill identification and developer portfolio representation.
