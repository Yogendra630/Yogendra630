import React, { useState, useEffect } from 'react';
import {
  Download,
  Eye,
  Code2,
  Sparkles,
  ExternalLink,
  Check,
  Copy,
  Laptop,
  Smartphone,
  Monitor,
  RotateCcw,
  FileText,
  FolderArchive,
  Sun,
  Moon,
  ShieldCheck,
  Layers,
  Terminal,
  UserCheck,
  Zap,
  Info
} from 'lucide-react';

interface SvgMeta {
  id: string;
  filename: string;
  title: string;
  purpose: string;
  viewBox: string;
  size: string;
  animDuration: string;
  description: string;
}

const SVG_LIST: SvgMeta[] = [
  {
    id: 'hero',
    filename: 'hero.svg',
    title: 'Animated Profile Hero',
    purpose: 'Hero introduction with cycling roles & portrait aura',
    viewBox: '0 0 850 360',
    size: '~388 KB',
    animDuration: '16s cycle',
    description: 'Animated greeting, name reveal, 4-role cycling title (Software Developer, Backend Engineer, AI/ML Enthusiast, Cloud & DevOps Learner), and glowing orbital character halo.'
  },
  {
    id: 'about',
    filename: 'about-life.svg',
    title: 'About Me & Engineering Philosophy',
    purpose: '3-Slide interactive carousel with active progress bars',
    viewBox: '0 0 850 300',
    size: '~10 KB',
    animDuration: '12s (4s / slide)',
    description: 'Cycles through Software Architecture, AI/ML Engineering, and Open Source & DevOps with live segment progress indicators and core Build-Learn-Improve-Ship philosophy.'
  },
  {
    id: 'stack',
    filename: 'stack.svg',
    title: 'Technology Ecosystem',
    purpose: '3 Tilted planetary orbits & categorized skill chips',
    viewBox: '0 0 850 420',
    size: '~13 KB',
    animDuration: 'Continuous orbital motion',
    description: '3 concentric elliptical orbits with orbiting particle satellites representing Core, Web, and AI/Cloud tooling, accompanied by grouped technology badges.'
  },
  {
    id: 'id-dashboard',
    filename: 'id-dashboard.svg',
    title: 'Hanging ID Badge & Metrics HUD',
    purpose: 'Physical lanyard pendulum swing + Developer HUD',
    viewBox: '0 0 850 380',
    size: '~390 KB',
    animDuration: 'Damped pendulum ±1.7° sway',
    description: 'A metallic-clasped developer credential card with laser-scanning barcode, drop-in pendulum momentum, and verified metrics HUD (10 public repositories, B.Tech CSE \'27).'
  },
  {
    id: 'connect',
    filename: 'connect.svg',
    title: "Let's Connect & Collaborate",
    purpose: 'Waist-up character pointing directly at social cards',
    viewBox: '0 0 850 300',
    size: '~275 KB',
    animDuration: 'Gentle bob & energy pulse',
    description: 'Yogendra\'s illustrated character pointing rightward to verified contact channels (GitHub @Yogendra630, LinkedIn, and internship opportunities).'
  }
];

const VERIFIED_PROJECTS = [
  {
    name: 'SmartContactManager',
    description: 'Full-stack contact management application with secure authentication, contact CRUD, pagination, and cloud storage.',
    tech: ['Java', 'Spring Boot', 'MySQL', 'MVC', 'Tailwind CSS'],
    url: 'https://github.com/Yogendra630/SmartContactManager'
  },
  {
    name: 'Stock Price Prediction ML',
    description: 'Time-series stock trend forecasting system using Deep Learning Long Short-Term Memory (LSTM) recurrent networks.',
    tech: ['Python', 'TensorFlow', 'Keras', 'yfinance', 'Streamlit'],
    url: 'https://github.com/Yogendra630/stock-price-prediction-ml'
  },
  {
    name: 'OpenSource Matchmaker',
    description: 'GitHub developer project discovery platform matching open-source opportunities to user language skills.',
    tech: ['TypeScript', 'React', 'GitHub API', 'Vite'],
    url: 'https://github.com/Yogendra630/OpenSourceMatchmaker'
  },
  {
    name: 'CloudDocs',
    description: 'Collaborative cloud document workspace with real-time editing, document organization, and clean UI.',
    tech: ['TypeScript', 'React', 'Cloud Architecture'],
    url: 'https://github.com/Yogendra630/cloud-Docs'
  },
  {
    name: 'GitHub Profile Analyzer',
    description: 'Interactive repository & profile analytics engine featuring commit breakdown, charts, and velocity statistics.',
    tech: ['JavaScript', 'React', 'Chart.js', 'GitHub API'],
    url: 'https://github.com/Yogendra630/github-profile-analyzer'
  }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'preview' | 'inspector' | 'assets' | 'deploy'>('preview');
  const [viewport, setViewport] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [ghTheme, setGhTheme] = useState<'dark' | 'light'>('dark');
  const [selectedSvg, setSelectedSvg] = useState<SvgMeta>(SVG_LIST[0]);
  const [svgSource, setSvgSource] = useState<string>('');
  const [reducedMotion, setReducedMotion] = useState<boolean>(false);
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [previewKey, setPreviewKey] = useState<number>(Date.now());
  const [timelineSec, setTimelineSec] = useState<number>(0);

  // Load SVG source when selectedSvg changes
  useEffect(() => {
    fetch(`/assets/${selectedSvg.filename}`)
      .then((r) => r.text())
      .then((text) => setSvgSource(text))
      .catch((err) => console.error(err));
  }, [selectedSvg]);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(null), 2500);
  };

  const getViewportWidth = () => {
    switch (viewport) {
      case 'desktop':
        return 'max-w-[895px]';
      case 'tablet':
        return 'max-w-[720px]';
      case 'mobile':
        return 'max-w-[390px]';
    }
  };

  return (
    <div className="min-h-screen bg-[#05070E] text-[#F5F7FB] selection:bg-[#247BFF] selection:text-white flex flex-col font-sans">
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-50 bg-[#070B16]/90 backdrop-blur-md border-b border-[#1E293B] px-4 lg:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-[#247BFF] to-[#FF354F] p-[1.5px] flex items-center justify-center shadow-lg shadow-blue-500/20">
            <div className="w-full h-full bg-[#070B16] rounded-[7px] flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-[#247BFF]" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm lg:text-base tracking-tight text-white">Yogendra Maurya</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-[#247BFF]/15 text-[#38BDF8] border border-[#247BFF]/30">
                @Yogendra630
              </span>
            </div>
            <p className="text-xs text-[#8E9BB5]">Animated GitHub Profile README Suite</p>
          </div>
        </div>

        {/* View mode tabs */}
        <div className="flex items-center bg-[#0D1527] p-1 rounded-xl border border-[#1E293B]">
          <button
            onClick={() => setActiveTab('preview')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'preview'
                ? 'bg-[#247BFF] text-white shadow-md shadow-blue-600/30'
                : 'text-[#8E9BB5] hover:text-white hover:bg-white/5'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            Live README
          </button>
          <button
            onClick={() => setActiveTab('inspector')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'inspector'
                ? 'bg-[#247BFF] text-white shadow-md shadow-blue-600/30'
                : 'text-[#8E9BB5] hover:text-white hover:bg-white/5'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            SVG Animation Lab
          </button>
          <button
            onClick={() => setActiveTab('assets')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'assets'
                ? 'bg-[#247BFF] text-white shadow-md shadow-blue-600/30'
                : 'text-[#8E9BB5] hover:text-white hover:bg-white/5'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5" />
            Character Assets
          </button>
          <button
            onClick={() => setActiveTab('deploy')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'deploy'
                ? 'bg-[#247BFF] text-white shadow-md shadow-blue-600/30'
                : 'text-[#8E9BB5] hover:text-white hover:bg-white/5'
            }`}
          >
            <FolderArchive className="w-3.5 h-3.5" />
            Publish Pack
          </button>
        </div>

        {/* Action button: Download ZIP */}
        <div className="flex items-center gap-2">
          <a
            href="/Yogendra630.zip"
            download="Yogendra630.zip"
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-gradient-to-r from-[#247BFF] to-[#3B82F6] hover:from-[#1D6CE5] hover:to-[#2563EB] text-white shadow-lg shadow-blue-600/25 transition-all cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            Download Yogendra630.zip
          </a>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 p-4 lg:p-8 max-w-7xl mx-auto w-full">
        {/* TAB 1: LIVE README SIMULATOR */}
        {activeTab === 'preview' && (
          <div className="space-y-6">
            {/* Simulator Controls Bar */}
            <div className="flex flex-wrap items-center justify-between gap-4 bg-[#0A1021] border border-[#1E293B] p-3.5 rounded-2xl">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-[#8E9BB5] uppercase tracking-wider">Viewport:</span>
                <div className="flex items-center bg-[#070B16] p-0.5 rounded-lg border border-[#1E293B]">
                  <button
                    onClick={() => setViewport('desktop')}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs transition-colors ${
                      viewport === 'desktop' ? 'bg-[#247BFF] text-white font-medium' : 'text-[#8E9BB5] hover:text-white'
                    }`}
                    title="Desktop (890px)"
                  >
                    <Monitor className="w-3.5 h-3.5" />
                    Desktop
                  </button>
                  <button
                    onClick={() => setViewport('tablet')}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs transition-colors ${
                      viewport === 'tablet' ? 'bg-[#247BFF] text-white font-medium' : 'text-[#8E9BB5] hover:text-white'
                    }`}
                    title="Tablet / Laptop (720px)"
                  >
                    <Laptop className="w-3.5 h-3.5" />
                    Laptop
                  </button>
                  <button
                    onClick={() => setViewport('mobile')}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs transition-colors ${
                      viewport === 'mobile' ? 'bg-[#247BFF] text-white font-medium' : 'text-[#8E9BB5] hover:text-white'
                    }`}
                    title="Mobile (390px)"
                  >
                    <Smartphone className="w-3.5 h-3.5" />
                    Mobile
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-3">
                {/* Theme toggle */}
                <div className="flex items-center gap-1 bg-[#070B16] p-0.5 rounded-lg border border-[#1E293B]">
                  <button
                    onClick={() => setGhTheme('dark')}
                    className={`flex items-center gap-1 px-2 py-1 rounded text-xs transition-colors ${
                      ghTheme === 'dark' ? 'bg-[#1E293B] text-white font-medium' : 'text-[#8E9BB5] hover:text-white'
                    }`}
                  >
                    <Moon className="w-3 h-3" />
                    Dark
                  </button>
                  <button
                    onClick={() => setGhTheme('light')}
                    className={`flex items-center gap-1 px-2 py-1 rounded text-xs transition-colors ${
                      ghTheme === 'light' ? 'bg-white text-black font-medium' : 'text-[#8E9BB5] hover:text-white'
                    }`}
                  >
                    <Sun className="w-3 h-3" />
                    Light
                  </button>
                </div>

                {/* Reduced motion toggle */}
                <button
                  onClick={() => setReducedMotion(!reducedMotion)}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs border transition-colors ${
                    reducedMotion
                      ? 'bg-amber-500/15 border-amber-500/40 text-amber-300'
                      : 'bg-[#070B16] border-[#1E293B] text-[#8E9BB5] hover:text-white'
                  }`}
                  title="Test prefers-reduced-motion fallback"
                >
                  <Zap className="w-3 h-3" />
                  {reducedMotion ? 'Reduced Motion: ON' : 'Reduced Motion: OFF'}
                </button>

                {/* Refresh key button */}
                <button
                  onClick={() => setPreviewKey(Date.now())}
                  className="p-1.5 rounded-lg bg-[#070B16] border border-[#1E293B] text-[#8E9BB5] hover:text-white hover:bg-white/5 transition-colors"
                  title="Replay Animations"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* GitHub Canvas Container */}
            <div className="flex justify-center transition-all duration-300">
              <div
                className={`w-full ${getViewportWidth()} transition-all duration-300 rounded-xl border ${
                  ghTheme === 'dark' ? 'bg-[#0D1117] border-[#30363D]' : 'bg-white border-[#D0D7DE]'
                } p-4 sm:p-7 shadow-2xl`}
              >
                {/* GitHub File Header Bar */}
                <div
                  className={`flex items-center justify-between pb-4 mb-6 border-b text-xs ${
                    ghTheme === 'dark' ? 'border-[#30363D] text-[#8B949E]' : 'border-[#D0D7DE] text-[#57606A]'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Terminal className="w-3.5 h-3.5" />
                    <span className="font-semibold text-sm font-mono">Yogendra630 / README.md</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-md bg-[#247BFF]/10 text-[#38BDF8] border border-[#247BFF]/20 text-[11px] font-mono">
                      Raw View
                    </span>
                  </div>
                </div>

                {/* Profile Content */}
                <div className={`space-y-6 ${reducedMotion ? 'motion-reduce' : ''}`}>
                  {/* Title */}
                  <h1
                    className={`text-2xl font-bold tracking-tight ${
                      ghTheme === 'dark' ? 'text-[#F0F6FC]' : 'text-[#1F2328]'
                    }`}
                  >
                    Hi, I&apos;m Yogendra Maurya 👋
                  </h1>

                  {/* 1. Hero SVG */}
                  <div className="rounded-xl overflow-hidden shadow-lg border border-[#1E293B]">
                    <img
                      key={`hero-${previewKey}`}
                      src={`/assets/hero.svg?v=${previewKey}`}
                      alt="Introduction"
                      className="w-full h-auto block"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  {/* 2. About Me SVG */}
                  <div className="rounded-xl overflow-hidden shadow-lg border border-[#1E293B]">
                    <img
                      key={`about-${previewKey}`}
                      src={`/assets/about-life.svg?v=${previewKey}`}
                      alt="About Me"
                      className="w-full h-auto block"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  {/* 3. Tech Stack SVG */}
                  <div className="rounded-xl overflow-hidden shadow-lg border border-[#1E293B]">
                    <img
                      key={`stack-${previewKey}`}
                      src={`/assets/stack.svg?v=${previewKey}`}
                      alt="Technology Stack"
                      className="w-full h-auto block"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  {/* 4. Featured Projects Section */}
                  <div className="pt-4">
                    <h2
                      className={`text-xl font-bold mb-4 flex items-center gap-2 ${
                        ghTheme === 'dark' ? 'text-[#F0F6FC]' : 'text-[#1F2328]'
                      }`}
                    >
                      <span>🚀</span> Featured Projects
                    </h2>
                    <p className={`text-xs mb-4 ${ghTheme === 'dark' ? 'text-[#8B949E]' : 'text-[#57606A]'}`}>
                      Curated repositories verified directly against public GitHub activity:
                    </p>

                    <div className="overflow-x-auto rounded-lg border border-[#30363D]">
                      <table
                        className={`w-full text-xs text-left ${
                          ghTheme === 'dark' ? 'text-[#C9D1D9]' : 'text-[#24292F]'
                        }`}
                      >
                        <thead
                          className={`uppercase text-[11px] font-semibold ${
                            ghTheme === 'dark'
                              ? 'bg-[#161B22] text-[#F0F6FC] border-b border-[#30363D]'
                              : 'bg-[#F6F8FA] text-[#1F2328] border-b border-[#D0D7DE]'
                          }`}
                        >
                          <tr>
                            <th className="py-2.5 px-3">Project</th>
                            <th className="py-2.5 px-3">Description</th>
                            <th className="py-2.5 px-3">Technologies</th>
                            <th className="py-2.5 px-3 text-right">Repository</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#30363D]/60">
                          {VERIFIED_PROJECTS.map((proj, idx) => (
                            <tr
                              key={idx}
                              className={`transition-colors ${
                                ghTheme === 'dark' ? 'hover:bg-[#161B22]/50' : 'hover:bg-[#F6F8FA]'
                              }`}
                            >
                              <td className="py-3 px-3 font-semibold whitespace-nowrap">
                                <a
                                  href={proj.url}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="text-[#58A6FF] hover:underline"
                                >
                                  {proj.name}
                                </a>
                              </td>
                              <td className="py-3 px-3 max-w-xs">{proj.description}</td>
                              <td className="py-3 px-3">
                                <div className="flex flex-wrap gap-1">
                                  {proj.tech.map((t, tidx) => (
                                    <span
                                      key={tidx}
                                      className={`px-1.5 py-0.5 rounded text-[10px] ${
                                        ghTheme === 'dark'
                                          ? 'bg-[#21262D] text-[#8B949E] border border-[#30363D]'
                                          : 'bg-[#EAEEF2] text-[#57606A] border border-[#D0D7DE]'
                                      }`}
                                    >
                                      {t}
                                    </span>
                                  ))}
                                </div>
                              </td>
                              <td className="py-3 px-3 text-right whitespace-nowrap">
                                <a
                                  href={proj.url}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="inline-flex items-center gap-1 text-[#58A6FF] hover:underline font-medium"
                                >
                                  Repo <ExternalLink className="w-3 h-3" />
                                </a>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* 5. Developer ID Dashboard SVG */}
                  <div className="rounded-xl overflow-hidden shadow-lg border border-[#1E293B]">
                    <img
                      key={`dash-${previewKey}`}
                      src={`/assets/id-dashboard.svg?v=${previewKey}`}
                      alt="Developer Identity"
                      className="w-full h-auto block"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  {/* 6. Connect SVG */}
                  <div className="rounded-xl overflow-hidden shadow-lg border border-[#1E293B]">
                    <img
                      key={`conn-${previewKey}`}
                      src={`/assets/connect.svg?v=${previewKey}`}
                      alt="Connect"
                      className="w-full h-auto block"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  {/* Markdown Links below SVG for reliable GitHub clickability */}
                  <div className="pt-2">
                    <h2
                      className={`text-xl font-bold mb-3 ${
                        ghTheme === 'dark' ? 'text-[#F0F6FC]' : 'text-[#1F2328]'
                      }`}
                    >
                      🌐 Let&apos;s Connect
                    </h2>
                    <ul className={`text-xs space-y-2 ${ghTheme === 'dark' ? 'text-[#C9D1D9]' : 'text-[#24292F]'}`}>
                      <li className="flex items-center gap-2">
                        <strong className={ghTheme === 'dark' ? 'text-[#F0F6FC]' : 'text-[#1F2328]'}>GitHub:</strong>
                        <a
                          href="https://github.com/Yogendra630"
                          target="_blank"
                          rel="noreferrer"
                          className="text-[#58A6FF] hover:underline inline-flex items-center gap-1"
                        >
                          @Yogendra630 <ExternalLink className="w-3 h-3" />
                        </a>
                      </li>
                      <li className="flex items-center gap-2">
                        <strong className={ghTheme === 'dark' ? 'text-[#F0F6FC]' : 'text-[#1F2328]'}>LinkedIn:</strong>
                        <a
                          href="https://www.linkedin.com/in/yogendra-maurya-04a510288/"
                          target="_blank"
                          rel="noreferrer"
                          className="text-[#58A6FF] hover:underline inline-flex items-center gap-1"
                        >
                          linkedin.com/in/yogendra-maurya-04a510288 <ExternalLink className="w-3 h-3" />
                        </a>
                      </li>
                    </ul>
                  </div>

                  {/* Closing message */}
                  <div
                    className={`pt-6 pb-2 text-center border-t ${
                      ghTheme === 'dark' ? 'border-[#30363D] text-[#8B949E]' : 'border-[#D0D7DE] text-[#57606A]'
                    }`}
                  >
                    <p className="text-xs font-semibold tracking-wide">
                      ⚡ <b>Build. Learn. Ship. Repeat.</b> ⚡
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: SVG ANIMATION LAB & INSPECTOR */}
        {activeTab === 'inspector' && (
          <div className="space-y-6">
            {/* SVG Selector Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              {SVG_LIST.map((svg) => (
                <button
                  key={svg.id}
                  onClick={() => setSelectedSvg(svg)}
                  className={`p-3.5 rounded-xl border text-left transition-all ${
                    selectedSvg.id === svg.id
                      ? 'bg-[#121B33] border-[#247BFF] shadow-lg shadow-blue-500/10'
                      : 'bg-[#0A1021] border-[#1E293B] hover:border-[#334155]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-mono font-bold text-[#38BDF8]">{svg.filename}</span>
                    <span className="text-[10px] text-[#8E9BB5]">{svg.size}</span>
                  </div>
                  <h4 className="text-xs font-semibold text-white truncate">{svg.title}</h4>
                  <p className="text-[11px] text-[#8E9BB5] truncate mt-0.5">{svg.animDuration}</p>
                </button>
              ))}
            </div>

            {/* Inspection Deck */}
            <div className="bg-[#0A1021] border border-[#1E293B] rounded-2xl p-5 space-y-6">
              {/* Header Info */}
              <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-[#1E293B]">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-bold text-white">{selectedSvg.title}</h3>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#1E293B] text-[#93C5FD]">
                      {selectedSvg.filename}
                    </span>
                  </div>
                  <p className="text-xs text-[#8E9BB5] mt-1">{selectedSvg.description}</p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => copyToClipboard(svgSource, 'svg-code')}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#121B33] border border-[#247BFF]/40 text-[#93C5FD] hover:bg-[#247BFF] hover:text-white transition-all"
                  >
                    {copiedText === 'svg-code' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    Copy SVG Code
                  </button>
                  <a
                    href={`/assets/${selectedSvg.filename}`}
                    download={selectedSvg.filename}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#247BFF] text-white hover:bg-blue-600 transition-all"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download File
                  </a>
                </div>
              </div>

              {/* Time Scrubber & QA Validation Bar */}
              <div className="bg-[#070B16] p-3.5 rounded-xl border border-[#1E293B] flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-[#8E9BB5]">QA Inspection Scrub:</span>
                  <div className="flex items-center gap-1.5">
                    {[0, 2, 5, 9, 13].map((sec) => (
                      <button
                        key={sec}
                        onClick={() => {
                          setTimelineSec(sec);
                          setPreviewKey(Date.now());
                        }}
                        className={`px-2.5 py-1 rounded text-xs font-mono font-semibold transition-all ${
                          timelineSec === sec
                            ? 'bg-[#247BFF] text-white'
                            : 'bg-[#10172A] text-[#8E9BB5] hover:text-white hover:bg-[#1E293B]'
                        }`}
                      >
                        {sec}s
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex items-center gap-3 text-xs text-[#8E9BB5]">
                  <span className="flex items-center gap-1 text-emerald-400">
                    <ShieldCheck className="w-3.5 h-3.5" /> 100% Self-Contained
                  </span>
                  <span>•</span>
                  <span className="font-mono">viewBox: {selectedSvg.viewBox}</span>
                  <span>•</span>
                  <span>Zero foreignObject</span>
                </div>
              </div>

              {/* Live Render Area */}
              <div className="bg-[#070B16] border border-[#1E293B] rounded-xl p-4 flex items-center justify-center">
                <div className="w-full max-w-[850px] overflow-hidden rounded-lg shadow-xl">
                  <img
                    key={`${selectedSvg.id}-${previewKey}`}
                    src={`/assets/${selectedSvg.filename}?v=${previewKey}`}
                    alt={selectedSvg.title}
                    className="w-full h-auto block"
                    referrerPolicy="no-referrer"
                  />
                </div>
              </div>

              {/* Raw SVG Code Peek */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs text-[#8E9BB5]">
                  <span className="font-semibold flex items-center gap-1.5">
                    <Code2 className="w-3.5 h-3.5 text-[#247BFF]" /> Clean SVG Markup
                  </span>
                  <span className="font-mono text-[11px]">{svgSource.length.toLocaleString()} characters</span>
                </div>
                <div className="relative">
                  <pre className="max-h-56 overflow-auto p-4 rounded-xl bg-[#070B16] border border-[#1E293B] text-[11px] font-mono text-[#94A3B8] leading-relaxed">
                    {svgSource.slice(0, 2000)}
                    {svgSource.length > 2000 && '\n\n... [Remaining SVG markup truncated for display] ...'}
                  </pre>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: CHARACTER ASSETS */}
        {activeTab === 'assets' && (
          <div className="space-y-6">
            <div className="bg-[#0A1021] border border-[#1E293B] rounded-2xl p-6">
              <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-[#1E293B]">
                <div>
                  <h3 className="text-lg font-bold text-white flex items-center gap-2">
                    <UserCheck className="w-5 h-5 text-[#247BFF]" /> Generated Character Assets
                  </h3>
                  <p className="text-xs text-[#8E9BB5] mt-1">
                    Matching semi-realistic illustrated portraits rendered with transparent PNG alpha channels,
                    accurate facial structure, dark tailored tech blazer, and neon rim lighting.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    Transparent PNG (Alpha = 0)
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                {/* Asset 1: assets/id.png */}
                <div className="bg-[#070B16] border border-[#1E293B] rounded-xl p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs font-mono font-bold text-[#38BDF8]">assets/id.png</span>
                      <h4 className="text-sm font-bold text-white">Character ID Portrait</h4>
                    </div>
                    <span className="text-xs text-[#8E9BB5]">800 × 800 px</span>
                  </div>

                  {/* Image container with checkerboard background to prove alpha transparency */}
                  <div className="w-full aspect-square rounded-xl overflow-hidden bg-[radial-gradient(#1E293B_1px,transparent_1px)] bg-[size:16px_16px] bg-[#0A0F1E] flex items-center justify-center p-4 border border-[#1E293B]">
                    <img
                      src="/assets/id.png"
                      alt="Yogendra Maurya ID Portrait"
                      className="max-h-full max-w-full object-contain filter drop-shadow-[0_10px_20px_rgba(0,0,0,0.6)]"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  <div className="text-xs text-[#8E9BB5] space-y-1">
                    <p>• Framed from chest upward with full head visible</p>
                    <p>• Subtle electric-blue (#247BFF) and crimson (#FF354F) rim highlights</p>
                    <p>• Inlined into <code className="text-[#93C5FD]">hero.svg</code> & <code className="text-[#93C5FD]">id-dashboard.svg</code></p>
                  </div>

                  <a
                    href="/assets/id.png"
                    download="id.png"
                    className="flex items-center justify-center gap-2 w-full py-2 rounded-lg text-xs font-semibold bg-[#121B33] border border-[#247BFF]/40 text-[#93C5FD] hover:bg-[#247BFF] hover:text-white transition-all"
                  >
                    <Download className="w-3.5 h-3.5" /> Download id.png
                  </a>
                </div>

                {/* Asset 2: assets/right_pointing.png */}
                <div className="bg-[#070B16] border border-[#1E293B] rounded-xl p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs font-mono font-bold text-[#38BDF8]">assets/right_pointing.png</span>
                      <h4 className="text-sm font-bold text-white">Right-Pointing Character</h4>
                    </div>
                    <span className="text-xs text-[#8E9BB5]">960 × 720 px</span>
                  </div>

                  {/* Image container with checkerboard background */}
                  <div className="w-full aspect-square rounded-xl overflow-hidden bg-[radial-gradient(#1E293B_1px,transparent_1px)] bg-[size:16px_16px] bg-[#0A0F1E] flex items-center justify-center p-4 border border-[#1E293B]">
                    <img
                      src="/assets/right_pointing.png"
                      alt="Yogendra Maurya Right Pointing Character"
                      className="max-h-full max-w-full object-contain filter drop-shadow-[0_10px_20px_rgba(0,0,0,0.6)]"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  <div className="text-xs text-[#8E9BB5] space-y-1">
                    <p>• Framed from waist upward, positioned on the left side</p>
                    <p>• Right arm gesturing toward contact cards</p>
                    <p>• Inlined into <code className="text-[#93C5FD]">connect.svg</code> for zero broken links</p>
                  </div>

                  <a
                    href="/assets/right_pointing.png"
                    download="right_pointing.png"
                    className="flex items-center justify-center gap-2 w-full py-2 rounded-lg text-xs font-semibold bg-[#121B33] border border-[#247BFF]/40 text-[#93C5FD] hover:bg-[#247BFF] hover:text-white transition-all"
                  >
                    <Download className="w-3.5 h-3.5" /> Download right_pointing.png
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: PUBLISH PACK & DEPLOY GUIDE */}
        {activeTab === 'deploy' && (
          <div className="space-y-6">
            {/* Download Banner */}
            <div className="bg-gradient-to-r from-[#0C152B] via-[#0E1B3A] to-[#161226] border border-[#247BFF]/40 rounded-2xl p-6 lg:p-8 flex flex-wrap items-center justify-between gap-6 shadow-2xl">
              <div className="space-y-2 max-w-xl">
                <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full text-xs font-semibold bg-[#247BFF]/15 text-[#38BDF8] border border-[#247BFF]/30">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Production Ready Package Verified
                </div>
                <h3 className="text-xl lg:text-2xl font-bold text-white tracking-tight">
                  Deploy Your Profile to GitHub in 3 Minutes
                </h3>
                <p className="text-xs lg:text-sm text-[#8E9BB5]">
                  Everything is formatted, verified, and pre-packaged with correct relative paths.
                  Upload directly to the special <code className="text-[#93C5FD] font-mono">Yogendra630/Yogendra630</code> repository.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-3">
                <a
                  href="/Yogendra630.zip"
                  download="Yogendra630.zip"
                  className="flex items-center gap-2 px-5 py-3 rounded-xl text-sm font-bold bg-gradient-to-r from-[#247BFF] to-[#3B82F6] hover:from-[#1D6CE5] hover:to-[#2563EB] text-white shadow-xl shadow-blue-600/30 transition-all cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  Download Complete Zip (1.6 MB)
                </a>
              </div>
            </div>

            {/* Step-by-Step Instructions */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-[#0A1021] border border-[#1E293B] rounded-xl p-5 space-y-2.5">
                <div className="w-8 h-8 rounded-lg bg-[#247BFF]/15 border border-[#247BFF]/30 flex items-center justify-center font-bold text-sm text-[#38BDF8]">
                  1
                </div>
                <h4 className="text-sm font-bold text-white">Extract the Package</h4>
                <p className="text-xs text-[#8E9BB5]">
                  Download and unzip <code className="text-[#93C5FD]">Yogendra630.zip</code>. It contains <code className="text-[#93C5FD]">README.md</code>, the <code className="text-[#93C5FD]">assets/</code> directory, and <code className="text-[#93C5FD]">preview.html</code>.
                </p>
              </div>

              <div className="bg-[#0A1021] border border-[#1E293B] rounded-xl p-5 space-y-2.5">
                <div className="w-8 h-8 rounded-lg bg-[#247BFF]/15 border border-[#247BFF]/30 flex items-center justify-center font-bold text-sm text-[#38BDF8]">
                  2
                </div>
                <h4 className="text-sm font-bold text-white">Push to GitHub</h4>
                <p className="text-xs text-[#8E9BB5]">
                  Commit and push the files directly to your existing <code className="text-[#93C5FD]">https://github.com/Yogendra630/Yogendra630</code> repository on the main branch.
                </p>
              </div>

              <div className="bg-[#0A1021] border border-[#1E293B] rounded-xl p-5 space-y-2.5">
                <div className="w-8 h-8 rounded-lg bg-[#247BFF]/15 border border-[#247BFF]/30 flex items-center justify-center font-bold text-sm text-[#38BDF8]">
                  3
                </div>
                <h4 className="text-sm font-bold text-white">Live Automatically</h4>
                <p className="text-xs text-[#8E9BB5]">
                  Visit your profile at <code className="text-[#93C5FD]">github.com/Yogendra630</code>. GitHub will immediately render all 5 animated sections!
                </p>
              </div>
            </div>

            {/* Archive Content Manifest */}
            <div className="bg-[#0A1021] border border-[#1E293B] rounded-2xl p-6 space-y-4">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <FolderArchive className="w-4 h-4 text-[#247BFF]" /> Package Manifest Structure
              </h4>

              <div className="bg-[#070B16] border border-[#1E293B] rounded-xl p-4 font-mono text-xs text-[#94A3B8] leading-relaxed">
                <div className="text-white font-bold">Yogendra630/</div>
                <div className="pl-4">├── README.md <span className="text-[#64748B]">(Main GitHub markdown profile)</span></div>
                <div className="pl-4">├── preview.html <span className="text-[#64748B]">(Offline browser preview tool)</span></div>
                <div className="pl-4">├── README_PREVIEW.png <span className="text-[#64748B]">(High-res composite preview banner)</span></div>
                <div className="pl-4">├── <span className="text-[#38BDF8]">assets/</span></div>
                <div className="pl-8">├── hero.svg <span className="text-[#64748B]">(Animated Introduction)</span></div>
                <div className="pl-8">├── about-life.svg <span className="text-[#64748B]">(Interests &amp; philosophy carousel)</span></div>
                <div className="pl-8">├── stack.svg <span className="text-[#64748B]">(Planetary orbits &amp; tech categories)</span></div>
                <div className="pl-8">├── id-dashboard.svg <span className="text-[#64748B]">(Hanging ID badge &amp; stats HUD)</span></div>
                <div className="pl-8">├── connect.svg <span className="text-[#64748B]">(Pointing character &amp; contact cards)</span></div>
                <div className="pl-8">├── id.png <span className="text-[#64748B]">(Transparent portrait PNG, 800x800)</span></div>
                <div className="pl-8">└── right_pointing.png <span className="text-[#64748B]">(Transparent pointing character PNG, 960x720)</span></div>
                <div className="pl-4">└── <span className="text-[#38BDF8]">LICENSES/</span></div>
                <div className="pl-8">└── ASSET_LICENSES.md <span className="text-[#64748B]">(Full attribution &amp; permissive license)</span></div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-[#1E293B] bg-[#070B16] px-4 lg:px-8 py-4 text-center text-xs text-[#64748B]">
        Designed for <strong className="text-white">Yogendra Maurya</strong> (@Yogendra630) • Built with React, Vite &amp; Resvg
      </footer>
    </div>
  );
}
