import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { Resvg } from '@resvg/resvg-js';
import JSZip from 'jszip';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

const outDir = path.join(rootDir, 'Yogendra630');
const assetsDir = path.join(outDir, 'assets');
const licensesDir = path.join(outDir, 'LICENSES');
const publicAssetsDir = path.join(rootDir, 'public', 'assets');

[outDir, assetsDir, licensesDir, publicAssetsDir].forEach(dir => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

console.log('Building Yogendra630 animated GitHub Profile assets...');

// 1. CHARACTER VECTOR ART FOR ID PORTRAIT (Chest Upward, 800x800)
// Features: Warm South Asian skin tone, neat textured black hair with pompadour/fade,
// expressive brown eyes, neat light stubble goatee, black tech blazer with open white collar shirt,
// electric blue (#247BFF) and crimson (#FF354F) rim lighting, pure transparent background.
const idPortraitSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 800" width="800" height="800">
  <defs>
    <radialGradient id="rim-blue" cx="15%" cy="35%" r="70%">
      <stop offset="0%" stop-color="#247BFF" stop-opacity="0.85"/>
      <stop offset="60%" stop-color="#247BFF" stop-opacity="0.1"/>
      <stop offset="100%" stop-color="#247BFF" stop-opacity="0"/>
    </radialGradient>
    <radialGradient id="rim-crimson" cx="85%" cy="35%" r="70%">
      <stop offset="0%" stop-color="#FF354F" stop-opacity="0.85"/>
      <stop offset="60%" stop-color="#FF354F" stop-opacity="0.1"/>
      <stop offset="100%" stop-color="#FF354F" stop-opacity="0"/>
    </radialGradient>
    <linearGradient id="skin-base" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#C58A59"/>
      <stop offset="50%" stop-color="#B27645"/>
      <stop offset="100%" stop-color="#965D30"/>
    </linearGradient>
    <linearGradient id="skin-shadow" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#965D30"/>
      <stop offset="100%" stop-color="#73411C"/>
    </linearGradient>
    <linearGradient id="blazer-grad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#161C2C"/>
      <stop offset="50%" stop-color="#0E121D"/>
      <stop offset="100%" stop-color="#080A11"/>
    </linearGradient>
    <linearGradient id="lapel-grad" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#21293E"/>
      <stop offset="100%" stop-color="#121624"/>
    </linearGradient>
    <filter id="glow-b" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="8" result="blur"/>
      <feComposite in="SourceGraphic" in2="blur" operator="over"/>
    </filter>
  </defs>

  <!-- Ambient Rim Glows around subject -->
  <circle cx="280" cy="360" r="260" fill="url(#rim-blue)" filter="url(#glow-b)"/>
  <circle cx="520" cy="360" r="260" fill="url(#rim-crimson)" filter="url(#glow-b)"/>

  <!-- SHOULDERS & SUIT BLAZER -->
  <g id="clothing">
    <!-- Back shoulders -->
    <path d="M 180 800 C 180 620, 240 520, 330 490 L 470 490 C 560 520, 620 620, 620 800 Z" fill="url(#blazer-grad)"/>

    <!-- Left shoulder edge blue highlight -->
    <path d="M 180 800 C 180 620, 240 520, 330 490 L 340 510 C 260 540, 205 630, 205 800 Z" fill="#247BFF" opacity="0.6"/>

    <!-- Right shoulder edge crimson highlight -->
    <path d="M 620 800 C 620 620, 560 520, 470 490 L 460 510 C 540 540, 595 630, 595 800 Z" fill="#FF354F" opacity="0.5"/>

    <!-- White collared shirt (open collar) -->
    <path d="M 340 480 L 400 620 L 460 480 L 430 460 L 400 510 L 370 460 Z" fill="#F0F4FA"/>
    <!-- Shirt shadow & V-neck -->
    <path d="M 370 480 L 400 580 L 430 480 L 415 480 L 400 540 L 385 480 Z" fill="#D2DCED"/>
    <!-- Exposed neck/collarbone skin -->
    <path d="M 375 450 L 400 535 L 425 450 Z" fill="url(#skin-shadow)"/>

    <!-- Left Shirt Collar -->
    <polygon points="340,460 385,530 365,540 330,475" fill="#FFFFFF"/>
    <!-- Right Shirt Collar -->
    <polygon points="460,460 415,530 435,540 470,475" fill="#E8EEF8"/>

    <!-- Suit Lapels -->
    <!-- Left Lapel -->
    <path d="M 330 485 L 385 640 L 345 800 L 250 800 C 265 670, 290 560, 330 485 Z" fill="url(#lapel-grad)"/>
    <!-- Left Lapel edge neon piping -->
    <path d="M 330 485 L 385 640 L 380 645 L 326 490 Z" fill="#247BFF" opacity="0.75"/>

    <!-- Right Lapel -->
    <path d="M 470 485 L 415 640 L 455 800 L 550 800 C 535 670, 510 560, 470 485 Z" fill="url(#lapel-grad)"/>
    <!-- Right Lapel edge neon piping -->
    <path d="M 470 485 L 415 640 L 420 645 L 474 490 Z" fill="#FF354F" opacity="0.7"/>

    <!-- Tie space / inner V-button -->
    <circle cx="400" cy="710" r="7" fill="#080A11"/>
    <circle cx="400" cy="710" r="5" stroke="#2A344E" stroke-width="1.5" fill="none"/>
  </g>

  <!-- NECK & JAW -->
  <g id="neck">
    <!-- Neck -->
    <path d="M 345 380 L 345 480 C 370 510, 430 510, 455 480 L 455 380 Z" fill="url(#skin-base)"/>
    <!-- Neck shadows under chin -->
    <path d="M 345 380 C 375 425, 425 425, 455 380 L 455 420 C 425 450, 375 450, 345 420 Z" fill="url(#skin-shadow)" opacity="0.7"/>
    <!-- Adam's apple subtle shadow -->
    <path d="M 395 435 L 405 435 L 400 445 Z" fill="#855228" opacity="0.5"/>
  </g>

  <!-- HEAD & FACE -->
  <g id="face">
    <!-- Ears -->
    <!-- Left Ear -->
    <path d="M 290 290 C 270 295, 265 345, 290 365 C 295 350, 298 310, 290 290 Z" fill="#B27645"/>
    <path d="M 285 305 C 277 315, 277 335, 287 345" stroke="#855228" stroke-width="2.5" fill="none"/>
    <!-- Blue rim on left ear -->
    <path d="M 276 300 C 268 320, 270 340, 284 358" stroke="#247BFF" stroke-width="3" fill="none" opacity="0.8"/>

    <!-- Right Ear -->
    <path d="M 510 290 C 530 295, 535 345, 510 365 C 505 350, 502 310, 510 290 Z" fill="#B27645"/>
    <path d="M 515 305 C 523 315, 523 335, 513 345" stroke="#855228" stroke-width="2.5" fill="none"/>
    <!-- Crimson rim on right ear -->
    <path d="M 524 300 C 532 320, 530 340, 516 358" stroke="#FF354F" stroke-width="3" fill="none" opacity="0.8"/>

    <!-- Face Shape (Jaw & Cheeks matching Yogendra) -->
    <path d="M 290 270 C 290 190, 510 190, 510 270 C 510 335, 500 375, 465 405 C 435 430, 365 430, 335 405 C 300 375, 290 335, 290 270 Z" fill="url(#skin-base)"/>

    <!-- Jawline definition and 5 o'clock shadow / stubble -->
    <path d="M 315 345 C 340 375, 360 415, 400 418 C 440 415, 460 375, 485 345 C 475 390, 445 428, 400 428 C 355 428, 325 390, 315 345 Z" fill="#5A3A22" opacity="0.35"/>

    <!-- Upper Lip Mustache Stubble -->
    <path d="M 370 364 C 385 358, 415 358, 430 364 C 418 369, 382 369, 370 364 Z" fill="#5A3A22" opacity="0.45"/>

    <!-- Chin Goatee Stubble -->
    <ellipse cx="400" cy="405" rx="30" ry="14" fill="#5A3A22" opacity="0.4"/>

    <!-- Cheeks warmth -->
    <ellipse cx="340" cy="325" rx="28" ry="16" fill="#C96B50" opacity="0.18"/>
    <ellipse cx="460" cy="325" rx="28" ry="16" fill="#C96B50" opacity="0.18"/>

    <!-- Eyebrows (Strong, defined, neat) -->
    <path d="M 325 262 Q 355 250 380 262 Q 355 256 325 262 Z" fill="#181412"/>
    <path d="M 475 262 Q 445 250 420 262 Q 445 256 475 262 Z" fill="#181412"/>

    <!-- Eyes (Deep brown almond eyes with focus) -->
    <!-- Left Eye -->
    <ellipse cx="355" cy="285" rx="20" ry="11" fill="#F8F9FA"/>
    <circle cx="355" cy="285" r="9" fill="#3D2314"/>
    <circle cx="355" cy="285" r="5" fill="#100C08"/>
    <circle cx="353" cy="282" r="2.5" fill="#FFFFFF"/>
    <path d="M 333 285 Q 355 272 377 285" stroke="#1F1610" stroke-width="2.5" fill="none"/>
    <path d="M 335 285 Q 355 296 375 285" stroke="#68452D" stroke-width="1.2" fill="none"/>

    <!-- Right Eye -->
    <ellipse cx="445" cy="285" rx="20" ry="11" fill="#F8F9FA"/>
    <circle cx="445" cy="285" r="9" fill="#3D2314"/>
    <circle cx="445" cy="285" r="5" fill="#100C08"/>
    <circle cx="443" cy="282" r="2.5" fill="#FFFFFF"/>
    <path d="M 423 285 Q 445 272 467 285" stroke="#1F1610" stroke-width="2.5" fill="none"/>
    <path d="M 425 285 Q 445 296 465 285" stroke="#68452D" stroke-width="1.2" fill="none"/>

    <!-- Nose (Defined natural bridge) -->
    <path d="M 395 275 L 392 328 C 388 335, 380 338, 386 342 C 394 345, 406 345, 414 342 C 420 338, 412 335, 408 328 L 405 275" fill="none" stroke="#8A572F" stroke-width="2"/>
    <ellipse cx="388" cy="338" rx="4" ry="2" fill="#5F3A1D" opacity="0.6"/>
    <ellipse cx="412" cy="338" rx="4" ry="2" fill="#5F3A1D" opacity="0.6"/>

    <!-- Lips (Natural masculine lips with friendly neutral expression) -->
    <path d="M 374 372 Q 400 368 426 372 Q 400 376 374 372 Z" fill="#99574A"/>
    <path d="M 377 372 Q 400 383 423 372 Q 400 375 377 372 Z" fill="#824338"/>

    <!-- Left Face Blue Rim Highlight -->
    <path d="M 293 250 C 291 300, 305 365, 345 405" stroke="#247BFF" stroke-width="3" stroke-linecap="round" fill="none" opacity="0.8"/>
    <!-- Right Face Crimson Rim Highlight -->
    <path d="M 507 250 C 509 300, 495 365, 455 405" stroke="#FF354F" stroke-width="3" stroke-linecap="round" fill="none" opacity="0.75"/>
  </g>

  <!-- HAIR (Textured, voluminous, neat fade on sides matching photo) -->
  <g id="hair">
    <!-- Main Hair Mass -->
    <path d="M 285 240 C 280 180, 310 100, 400 95 C 490 100, 520 180, 515 240 C 500 230, 480 232, 455 228 C 420 224, 380 224, 345 228 C 320 232, 300 230, 285 240 Z" fill="#141113"/>
    
    <!-- Hair Volume & Texture Strands -->
    <path d="M 310 170 C 335 120, 385 105, 420 110 C 470 115, 500 160, 505 210 C 475 160, 425 140, 375 150 C 335 160, 315 180, 310 170 Z" fill="#241E22"/>
    <path d="M 350 140 C 380 110, 430 110, 460 135 C 430 120, 380 125, 350 140 Z" fill="#362F34"/>
    <path d="M 330 200 C 360 160, 410 155, 450 175 C 420 165, 370 170, 330 200 Z" fill="#241E22"/>
    <path d="M 380 115 C 400 95, 430 100, 445 120" stroke="#483F46" stroke-width="2.5" fill="none"/>
    <path d="M 340 145 C 365 125, 395 125, 415 140" stroke="#483F46" stroke-width="2" fill="none"/>

    <!-- Left sideburn & fade -->
    <path d="M 286 240 L 290 295 L 300 285 L 298 240 Z" fill="#181416"/>
    <!-- Right sideburn & fade -->
    <path d="M 514 240 L 510 295 L 500 285 L 502 240 Z" fill="#181416"/>

    <!-- Electric Blue Hair Rim (Top-Left) -->
    <path d="M 285 210 C 285 150, 330 105, 390 98" stroke="#247BFF" stroke-width="3.5" fill="none" opacity="0.85"/>
    <path d="M 310 170 C 330 130, 360 115, 400 108" stroke="#247BFF" stroke-width="2" fill="none" opacity="0.6"/>

    <!-- Crimson Hair Rim (Top-Right) -->
    <path d="M 515 210 C 515 150, 470 105, 410 98" stroke="#FF354F" stroke-width="3.5" fill="none" opacity="0.8"/>
  </g>
</svg>`;

// 2. CHARACTER VECTOR ART FOR RIGHT POINTING (Waist Upward, Left Positioned, Hand Pointing Right, 960x720)
const rightPointingSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 720" width="960" height="720">
  <defs>
    <radialGradient id="pt-rim-blue" cx="15%" cy="35%" r="70%">
      <stop offset="0%" stop-color="#247BFF" stop-opacity="0.8"/>
      <stop offset="70%" stop-color="#247BFF" stop-opacity="0"/>
    </radialGradient>
    <radialGradient id="pt-rim-crimson" cx="85%" cy="35%" r="70%">
      <stop offset="0%" stop-color="#FF354F" stop-opacity="0.8"/>
      <stop offset="70%" stop-color="#FF354F" stop-opacity="0"/>
    </radialGradient>
    <linearGradient id="pt-skin" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#C58A59"/>
      <stop offset="60%" stop-color="#B27645"/>
      <stop offset="100%" stop-color="#965D30"/>
    </linearGradient>
    <linearGradient id="pt-suit" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#182032"/>
      <stop offset="50%" stop-color="#0F1420"/>
      <stop offset="100%" stop-color="#080A10"/>
    </linearGradient>
    <filter id="pt-glow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="6" result="blur"/>
      <feComposite in="SourceGraphic" in2="blur" operator="over"/>
    </filter>
  </defs>

  <!-- Ambient rim glows -->
  <circle cx="180" cy="280" r="220" fill="url(#pt-rim-blue)" filter="url(#pt-glow)"/>
  <circle cx="420" cy="300" r="220" fill="url(#pt-rim-crimson)" filter="url(#pt-glow)"/>

  <!-- TORSO & ARMS (Positioned on the Left) -->
  <g id="pt-body">
    <!-- Back body -->
    <path d="M 60 720 C 60 520, 120 440, 220 420 L 380 420 C 440 440, 480 500, 500 720 Z" fill="url(#pt-suit)"/>

    <!-- Left Arm & Shoulder -->
    <path d="M 60 720 C 60 520, 110 440, 180 430 L 190 580 L 140 720 Z" fill="#131926"/>
    <!-- Left shoulder electric blue line -->
    <path d="M 70 720 C 70 535, 115 450, 180 430" stroke="#247BFF" stroke-width="4" fill="none" opacity="0.8"/>

    <!-- White Shirt & Collar -->
    <path d="M 240 410 L 300 530 L 360 410 L 330 395 L 300 440 L 270 395 Z" fill="#EEF3FA"/>
    <polygon points="240,400 280,465 260,475 230,410" fill="#FFFFFF"/>
    <polygon points="360,400 320,465 340,475 370,410" fill="#DDE5F5"/>
    <!-- Exposed neck -->
    <path d="M 270 380 L 300 455 L 330 380 Z" fill="#965D30"/>

    <!-- Suit Lapels -->
    <path d="M 230 420 L 280 550 L 250 720 L 170 720 C 180 600, 200 500, 230 420 Z" fill="#1E273D"/>
    <path d="M 230 420 L 280 550" stroke="#247BFF" stroke-width="2.5" fill="none" opacity="0.8"/>

    <path d="M 370 420 L 320 550 L 350 720 L 430 720 C 420 600, 400 500, 370 420 Z" fill="#1E273D"/>
    <path d="M 370 420 L 320 550" stroke="#FF354F" stroke-width="2.5" fill="none" opacity="0.75"/>

    <!-- RIGHT EXTENDED ARM POINTING FORWARD & RIGHT -->
    <!-- Upper arm -->
    <path d="M 380 430 C 440 440, 470 470, 520 480 L 490 560 C 440 540, 410 510, 370 490 Z" fill="#151C2C"/>
    <!-- Forearm extending to right -->
    <path d="M 490 520 L 680 480 C 700 485, 720 475, 740 480 L 730 535 L 480 570 Z" fill="#182133"/>
    <!-- Forearm sleeve cuff -->
    <rect x="715" y="475" width="22" height="62" rx="4" transform="rotate(-6 726 506)" fill="#0C101A" stroke="#247BFF" stroke-width="1.5"/>

    <!-- POINTING HAND & FINGERS (Pointing to the Right) -->
    <!-- Wrist & Palm -->
    <ellipse cx="750" cy="502" rx="20" ry="18" fill="url(#pt-skin)"/>
    
    <!-- Curled fingers (thumb, middle, ring, pinky) -->
    <path d="M 755 490 C 775 495, 775 520, 755 526" fill="#965D30" stroke="#804B22" stroke-width="2"/>
    <path d="M 758 502 C 778 506, 778 526, 756 532" fill="#B27645" stroke="#804B22" stroke-width="2"/>
    <path d="M 754 514 C 770 518, 770 534, 752 538" fill="#965D30" stroke="#804B22" stroke-width="2"/>
    
    <!-- Thumb resting over middle finger -->
    <path d="M 742 492 C 758 488, 770 500, 762 510 C 754 516, 742 506, 742 492 Z" fill="#C58A59"/>

    <!-- EXTENDED INDEX FINGER (Pointed sharply toward right) -->
    <path d="M 750 484 L 845 470 C 856 468, 862 478, 852 485 L 755 498 Z" fill="#C58A59" stroke="#804B22" stroke-width="1.5"/>
    <!-- Index Fingernail -->
    <ellipse cx="844" cy="477" rx="5" ry="3.5" transform="rotate(-7 844 477)" fill="#E0A77B"/>
    <!-- Light highlight on pointing finger -->
    <path d="M 760 486 L 840 474" stroke="#FFE0C2" stroke-width="1.5" stroke-linecap="round"/>
    <!-- Blue neon rim glow on pointing hand tip -->
    <circle cx="850" cy="477" r="14" fill="#247BFF" opacity="0.25" filter="url(#pt-glow)"/>
    <circle cx="850" cy="477" r="4" fill="#247BFF"/>
  </g>

  <!-- NECK & HEAD -->
  <g id="pt-head">
    <!-- Neck -->
    <path d="M 255 310 L 255 390 C 275 415, 325 415, 345 390 L 345 310 Z" fill="url(#pt-skin)"/>
    <path d="M 255 310 C 280 345, 320 345, 345 310 L 345 340 C 320 365, 280 365, 255 340 Z" fill="#804B22" opacity="0.65"/>

    <!-- Left Ear -->
    <path d="M 210 235 C 195 240, 190 280, 210 295 C 215 280, 218 250, 210 235 Z" fill="#B27645"/>
    <path d="M 200 242 C 194 256, 195 272, 205 288" stroke="#247BFF" stroke-width="2.5" fill="none" opacity="0.8"/>

    <!-- Right Ear -->
    <path d="M 390 235 C 405 240, 410 280, 390 295 C 385 280, 382 250, 390 235 Z" fill="#B27645"/>
    <path d="M 400 242 C 406 256, 405 272, 395 288" stroke="#FF354F" stroke-width="2.5" fill="none" opacity="0.8"/>

    <!-- Face Shape -->
    <path d="M 210 215 C 210 150, 390 150, 390 215 C 390 270, 380 305, 350 330 C 325 350, 275 350, 250 330 C 220 305, 210 270, 210 215 Z" fill="url(#pt-skin)"/>

    <!-- Jaw stubble & mustache -->
    <path d="M 230 275 C 250 300, 270 335, 300 338 C 330 335, 350 300, 370 275 C 362 312, 338 346, 300 346 C 262 346, 238 312, 230 275 Z" fill="#5A3A22" opacity="0.35"/>
    <path d="M 275 292 C 288 286, 312 286, 325 292 C 315 296, 285 296, 275 292 Z" fill="#5A3A22" opacity="0.45"/>
    <ellipse cx="300" cy="326" rx="22" ry="11" fill="#5A3A22" opacity="0.4"/>

    <!-- Eyebrows -->
    <path d="M 240 210 Q 265 198 285 210 Q 265 204 240 210 Z" fill="#181412"/>
    <path d="M 360 210 Q 335 198 315 210 Q 335 204 360 210 Z" fill="#181412"/>

    <!-- Eyes (Looking rightward toward content) -->
    <!-- Left Eye -->
    <ellipse cx="265" cy="228" rx="16" ry="9" fill="#F8F9FA"/>
    <circle cx="268" cy="228" r="7" fill="#3D2314"/>
    <circle cx="269" cy="228" r="4" fill="#100C08"/>
    <circle cx="267" cy="226" r="2" fill="#FFFFFF"/>
    <path d="M 249 228 Q 265 218 281 228" stroke="#1F1610" stroke-width="2" fill="none"/>

    <!-- Right Eye -->
    <ellipse cx="335" cy="228" rx="16" ry="9" fill="#F8F9FA"/>
    <circle cx="338" cy="228" r="7" fill="#3D2314"/>
    <circle cx="339" cy="228" r="4" fill="#100C08"/>
    <circle cx="337" cy="226" r="2" fill="#FFFFFF"/>
    <path d="M 319 228 Q 335 218 351 228" stroke="#1F1610" stroke-width="2" fill="none"/>

    <!-- Nose -->
    <path d="M 296 220 L 294 262 C 291 268, 284 270, 289 274 C 295 276, 305 276, 311 274 C 316 270, 309 268, 306 262 L 304 220" fill="none" stroke="#8A572F" stroke-width="1.8"/>

    <!-- Friendly smile lips -->
    <path d="M 280 298 Q 300 308 320 298 Q 300 303 280 298 Z" fill="#99574A"/>

    <!-- Hair (Matched hairstyle with neat taper) -->
    <path d="M 205 190 C 200 140, 230 75, 300 70 C 370 75, 400 140, 395 190 C 380 182, 360 184, 340 180 C 315 178, 285 178, 260 180 C 240 184, 220 182, 205 190 Z" fill="#141113"/>
    <path d="M 225 135 C 245 95, 290 80, 320 85 C 360 90, 385 125, 390 165 C 365 125, 325 110, 285 120 C 250 128, 230 145, 225 135 Z" fill="#241E22"/>
    <path d="M 260 110 C 285 88, 325 88, 350 108 C 325 96, 285 100, 260 110 Z" fill="#362F34"/>

    <!-- Sideburns -->
    <path d="M 206 190 L 210 235 L 218 225 L 216 190 Z" fill="#181416"/>
    <path d="M 394 190 L 390 235 L 382 225 L 384 190 Z" fill="#181416"/>

    <!-- Blue Hair Rim (Left) -->
    <path d="M 205 165 C 205 115, 240 80, 290 73" stroke="#247BFF" stroke-width="3" fill="none" opacity="0.85"/>
    <!-- Crimson Hair Rim (Right) -->
    <path d="M 395 165 C 395 115, 360 80, 310 73" stroke="#FF354F" stroke-width="3" fill="none" opacity="0.8"/>
  </g>
</svg>`;

// Render both SVGs to authentic PNG files using Resvg!
console.log('Rendering assets/id.png (800x800 transparent PNG)...');
const resvgId = new Resvg(idPortraitSvg, { fitTo: { mode: 'width', value: 800 } });
const idPngBuffer = resvgId.render().asPng();
fs.writeFileSync(path.join(assetsDir, 'id.png'), idPngBuffer);
fs.writeFileSync(path.join(publicAssetsDir, 'id.png'), idPngBuffer);
console.log(`id.png saved (${idPngBuffer.length} bytes)`);

console.log('Rendering assets/right_pointing.png (960x720 transparent PNG)...');
const resvgPt = new Resvg(rightPointingSvg, { fitTo: { mode: 'width', value: 960 } });
const ptPngBuffer = resvgPt.render().asPng();
fs.writeFileSync(path.join(assetsDir, 'right_pointing.png'), ptPngBuffer);
fs.writeFileSync(path.join(publicAssetsDir, 'right_pointing.png'), ptPngBuffer);
console.log(`right_pointing.png saved (${ptPngBuffer.length} bytes)`);

const idBase64 = `data:image/png;base64,${idPngBuffer.toString('base64')}`;
const ptBase64 = `data:image/png;base64,${ptPngBuffer.toString('base64')}`;

// 3. SVG A: hero.svg (Animated Introduction, 850x360)
const heroSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 850 360" width="100%" height="360" preserveAspectRatio="xMidYMid meet">
  <defs>
    <linearGradient id="hero-bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#070B16"/>
      <stop offset="60%" stop-color="#0A1021"/>
      <stop offset="100%" stop-color="#0E162D"/>
    </linearGradient>
    <linearGradient id="hero-border" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#247BFF" stop-opacity="0.8"/>
      <stop offset="50%" stop-color="#3B82F6" stop-opacity="0.2"/>
      <stop offset="100%" stop-color="#FF354F" stop-opacity="0.8"/>
    </linearGradient>
    <linearGradient id="hero-name-grad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#FFFFFF"/>
      <stop offset="45%" stop-color="#F5F7FB"/>
      <stop offset="80%" stop-color="#247BFF"/>
      <stop offset="100%" stop-color="#FF354F"/>
    </linearGradient>
    <linearGradient id="hero-role-grad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#247BFF"/>
      <stop offset="100%" stop-color="#60A5FA"/>
    </linearGradient>
    <radialGradient id="hero-halo" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#247BFF" stop-opacity="0.35"/>
      <stop offset="60%" stop-color="#FF354F" stop-opacity="0.15"/>
      <stop offset="100%" stop-color="#070B16" stop-opacity="0"/>
    </radialGradient>
    <pattern id="hero-dots" width="24" height="24" patternUnits="userSpaceOnUse">
      <circle cx="2" cy="2" r="1.2" fill="#247BFF" fill-opacity="0.15"/>
    </pattern>
    <clipPath id="hero-avatar-clip">
      <circle cx="680" cy="180" r="105"/>
    </clipPath>
    <filter id="hero-glow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="4" result="b"/>
      <feComposite in="SourceGraphic" in2="b" operator="over"/>
    </filter>
  </defs>

  <style>
    @keyframes hero-fade-in {
      0% { opacity: 0; transform: translateY(8px); }
      100% { opacity: 1; transform: translateY(0); }
    }
    @keyframes hero-pulse {
      0%, 100% { opacity: 0.3; transform: scale(1); }
      50% { opacity: 0.65; transform: scale(1.04); }
    }
    @keyframes hero-ring-spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    @keyframes hero-role-cycle {
      0%, 20% { opacity: 1; transform: translateY(0); }
      25%, 95% { opacity: 0; transform: translateY(-16px); }
      100% { opacity: 1; transform: translateY(0); }
    }
    @keyframes hero-role-2 {
      0%, 20% { opacity: 0; transform: translateY(16px); }
      25%, 45% { opacity: 1; transform: translateY(0); }
      50%, 100% { opacity: 0; transform: translateY(-16px); }
    }
    @keyframes hero-role-3 {
      0%, 45% { opacity: 0; transform: translateY(16px); }
      50%, 70% { opacity: 1; transform: translateY(0); }
      75%, 100% { opacity: 0; transform: translateY(-16px); }
    }
    @keyframes hero-role-4 {
      0%, 70% { opacity: 0; transform: translateY(16px); }
      75%, 95% { opacity: 1; transform: translateY(0); }
      100% { opacity: 0; transform: translateY(16px); }
    }
    @keyframes hero-live-pulse {
      0%, 100% { fill-opacity: 1; r: 4; }
      50% { fill-opacity: 0.4; r: 6; }
    }

    .hero-container { font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; }
    .hero-text-shimmer { animation: hero-fade-in 1.2s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
    .hero-orbit-ring { transform-origin: 680px 180px; animation: hero-ring-spin 30s linear infinite; }
    .hero-pulse-glow { transform-origin: 680px 180px; animation: hero-pulse 4s ease-in-out infinite; }
    
    .role-text-1 { animation: hero-role-cycle 16s ease-in-out infinite; }
    .role-text-2 { animation: hero-role-2 16s ease-in-out infinite; }
    .role-text-3 { animation: hero-role-3 16s ease-in-out infinite; }
    .role-text-4 { animation: hero-role-4 16s ease-in-out infinite; }
    .live-dot { animation: hero-live-pulse 2s ease-in-out infinite; }

    @media (prefers-reduced-motion: reduce) {
      .hero-orbit-ring, .hero-pulse-glow, .live-dot { animation: none !important; }
      .role-text-1 { opacity: 1 !important; transform: none !important; animation: none !important; }
      .role-text-2, .role-text-3, .role-text-4 { display: none !important; }
    }
  </style>

  <!-- Card Frame -->
  <rect x="2" y="2" width="846" height="356" rx="16" fill="url(#hero-bg)" stroke="url(#hero-border)" stroke-width="1.5"/>
  <rect x="2" y="2" width="846" height="356" rx="16" fill="url(#hero-dots)"/>

  <!-- Top Accent Horizon Line -->
  <path d="M 30 2 L 820 2" stroke="url(#hero-border)" stroke-width="2" stroke-linecap="round"/>

  <!-- Left Content Column -->
  <g class="hero-container" transform="translate(48, 45)">
    <!-- Status Badge -->
    <g transform="translate(0, 0)">
      <rect x="0" y="0" width="280" height="26" rx="13" fill="#111B33" stroke="#247BFF" stroke-width="1" stroke-opacity="0.4"/>
      <circle cx="14" cy="13" r="4" fill="#00FFB2" class="live-dot"/>
      <text x="26" y="17" fill="#88E7D2" font-size="11" font-weight="600" letter-spacing="0.5">OPEN TO OPPORTUNITIES</text>
      <circle cx="168" cy="13" r="2" fill="#3B82F6"/>
      <text x="178" y="17" fill="#8E9BB5" font-size="11" font-weight="500">NIET B.Tech '27</text>
    </g>

    <!-- Animated Greeting -->
    <g transform="translate(0, 52)">
      <text x="0" y="0" fill="#8E9BB5" font-size="16" font-weight="500" letter-spacing="1">
        HI THERE, I'M <tspan fill="#247BFF" font-size="18">👋</tspan>
      </text>
      <!-- Big Name -->
      <text x="0" y="42" fill="url(#hero-name-grad)" font-size="44" font-weight="800" letter-spacing="-0.5" filter="url(#hero-glow)">
        Yogendra Maurya
      </text>
    </g>

    <!-- Cycling Professional Roles (16s cycle) -->
    <g transform="translate(0, 138)">
      <text x="0" y="0" fill="#64748B" font-size="12" font-weight="600" letter-spacing="1.5">SPECIALIZING IN</text>
      
      <!-- Role 1 -->
      <g class="role-text-1">
        <text x="0" y="24" fill="#247BFF" font-size="20" font-weight="700">Software Developer</text>
        <text x="200" y="24" fill="#8E9BB5" font-size="14" font-weight="500">| Scalable Web &amp; Systems</text>
      </g>
      <!-- Role 2 -->
      <g class="role-text-2">
        <text x="0" y="24" fill="#60A5FA" font-size="20" font-weight="700">Backend Engineer</text>
        <text x="188" y="24" fill="#8E9BB5" font-size="14" font-weight="500">| Java • Spring Boot • REST APIs</text>
      </g>
      <!-- Role 3 -->
      <g class="role-text-3">
        <text x="0" y="24" fill="#FF354F" font-size="20" font-weight="700">AI / ML Enthusiast</text>
        <text x="180" y="24" fill="#8E9BB5" font-size="14" font-weight="500">| Python • TensorFlow • RAG</text>
      </g>
      <!-- Role 4 -->
      <g class="role-text-4">
        <text x="0" y="24" fill="#38BDF8" font-size="20" font-weight="700">Cloud &amp; DevOps Learner</text>
        <text x="238" y="24" fill="#8E9BB5" font-size="14" font-weight="500">| AWS • Docker • Linux</text>
      </g>
    </g>

    <!-- Concise Introduction -->
    <g transform="translate(0, 196)">
      <text x="0" y="0" fill="#CBD5E1" font-size="13.5" font-weight="400" line-height="20">
        CSE undergraduate focused on building practical, reliable software products,
      </text>
      <text x="0" y="20" fill="#94A3B8" font-size="13.5" font-weight="400">
        mastering modern backend architectures, and engineering intelligent ML solutions.
      </text>
    </g>

    <!-- Quick Tech Tags / Skills Pill Row -->
    <g transform="translate(0, 248)">
      <rect x="0" y="0" width="76" height="24" rx="6" fill="#141E33" stroke="#247BFF" stroke-width="1" stroke-opacity="0.3"/>
      <text x="38" y="16" fill="#93C5FD" font-size="11" font-weight="600" text-anchor="middle">Java &amp; Spring</text>

      <rect x="84" y="0" width="60" height="24" rx="6" fill="#141E33" stroke="#247BFF" stroke-width="1" stroke-opacity="0.3"/>
      <text x="114" y="16" fill="#93C5FD" font-size="11" font-weight="600" text-anchor="middle">Python</text>

      <rect x="152" y="0" width="98" height="24" rx="6" fill="#141E33" stroke="#247BFF" stroke-width="1" stroke-opacity="0.3"/>
      <text x="201" y="16" fill="#93C5FD" font-size="11" font-weight="600" text-anchor="middle">React &amp; TypeScript</text>

      <rect x="258" y="0" width="66" height="24" rx="6" fill="#141E33" stroke="#247BFF" stroke-width="1" stroke-opacity="0.3"/>
      <text x="291" y="16" fill="#93C5FD" font-size="11" font-weight="600" text-anchor="middle">MySQL</text>

      <rect x="332" y="0" width="82" height="24" rx="6" fill="#2A1420" stroke="#FF354F" stroke-width="1" stroke-opacity="0.3"/>
      <text x="373" y="16" fill="#FCA5A5" font-size="11" font-weight="600" text-anchor="middle">TensorFlow</text>

      <rect x="422" y="0" width="56" height="24" rx="6" fill="#141E33" stroke="#247BFF" stroke-width="1" stroke-opacity="0.3"/>
      <text x="450" y="16" fill="#93C5FD" font-size="11" font-weight="600" text-anchor="middle">AWS</text>
    </g>
  </g>

  <!-- Right Avatar & Orbital Showcase -->
  <g>
    <!-- Background Halo Glow -->
    <circle cx="680" cy="180" r="140" fill="url(#hero-halo)" class="hero-pulse-glow"/>

    <!-- Orbital Dash Rings -->
    <circle cx="680" cy="180" r="126" stroke="#247BFF" stroke-width="1" stroke-dasharray="8 12" stroke-opacity="0.4" fill="none" class="hero-orbit-ring"/>
    <circle cx="680" cy="180" r="115" stroke="#FF354F" stroke-width="1" stroke-dasharray="4 8" stroke-opacity="0.35" fill="none"/>

    <!-- Rotating Tech Nodes on Orbit -->
    <g class="hero-orbit-ring">
      <circle cx="680" cy="54" r="5" fill="#247BFF" filter="url(#hero-glow)"/>
      <circle cx="806" cy="180" r="4" fill="#FF354F"/>
      <circle cx="554" cy="180" r="4.5" fill="#60A5FA"/>
    </g>

    <!-- Avatar Hex/Circle Outer Ring -->
    <circle cx="680" cy="180" r="109" fill="#0A1020" stroke="#247BFF" stroke-width="2.5" stroke-opacity="0.8"/>
    
    <!-- Inlined Portrait Image -->
    <image href="${idBase64}" x="575" y="75" width="210" height="210" clip-path="url(#hero-avatar-clip)" preserveAspectRatio="xMidYMid slice"/>

    <!-- Tech HUD Accents around Avatar -->
    <rect x="635" y="296" width="90" height="20" rx="10" fill="#070B16" stroke="#247BFF" stroke-width="1"/>
    <text x="680" y="310" fill="#88E7D2" font-family="ui-sans-serif, system-ui" font-size="10" font-weight="700" text-anchor="middle" letter-spacing="1">VERIFIED ID</text>
  </g>
</svg>`;

// 4. SVG B: about-life.svg (About Me & Philosophy Carousel, 850x300)
const aboutLifeSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 850 300" width="100%" height="300" preserveAspectRatio="xMidYMid meet">
  <defs>
    <linearGradient id="about-bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#070B16"/>
      <stop offset="100%" stop-color="#0A1124"/>
    </linearGradient>
    <linearGradient id="about-border" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#247BFF" stop-opacity="0.7"/>
      <stop offset="50%" stop-color="#3B82F6" stop-opacity="0.15"/>
      <stop offset="100%" stop-color="#FF354F" stop-opacity="0.7"/>
    </linearGradient>
    <linearGradient id="about-accent-line" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#247BFF"/>
      <stop offset="100%" stop-color="#FF354F"/>
    </linearGradient>
    <pattern id="about-grid" width="20" height="20" patternUnits="userSpaceOnUse">
      <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#247BFF" stroke-width="0.5" stroke-opacity="0.08"/>
    </pattern>
  </defs>

  <style>
    @keyframes about-slide-1 {
      0%, 30% { opacity: 1; transform: translateX(0); }
      33%, 97% { opacity: 0; transform: translateX(12px); }
      100% { opacity: 1; transform: translateX(0); }
    }
    @keyframes about-slide-2 {
      0%, 30% { opacity: 0; transform: translateX(-12px); }
      33.3%, 63.3% { opacity: 1; transform: translateX(0); }
      66.6%, 100% { opacity: 0; transform: translateX(12px); }
    }
    @keyframes about-slide-3 {
      0%, 63.3% { opacity: 0; transform: translateX(-12px); }
      66.6%, 96.6% { opacity: 1; transform: translateX(0); }
      100% { opacity: 0; transform: translateX(12px); }
    }
    @keyframes about-prog-1 {
      0% { width: 0; }
      33.3% { width: 220px; }
      33.4%, 100% { width: 220px; opacity: 0.4; }
    }
    @keyframes about-prog-2 {
      0%, 33.3% { width: 0; }
      66.6% { width: 220px; }
      66.7%, 100% { width: 220px; opacity: 0.4; }
    }
    @keyframes about-prog-3 {
      0%, 66.6% { width: 0; }
      100% { width: 220px; }
    }

    .about-font { font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; }
    .slide-c-1 { animation: about-slide-1 12s ease-in-out infinite; }
    .slide-c-2 { animation: about-slide-2 12s ease-in-out infinite; }
    .slide-c-3 { animation: about-slide-3 12s ease-in-out infinite; }
    .bar-c-1 { animation: about-prog-1 12s linear infinite; }
    .bar-c-2 { animation: about-prog-2 12s linear infinite; }
    .bar-c-3 { animation: about-prog-3 12s linear infinite; }

    @media (prefers-reduced-motion: reduce) {
      .slide-c-1 { opacity: 1 !important; transform: none !important; animation: none !important; }
      .slide-c-2, .slide-c-3 { display: none !important; }
      .bar-c-1, .bar-c-2, .bar-c-3 { animation: none !important; width: 220px !important; }
    }
  </style>

  <!-- Frame -->
  <rect x="2" y="2" width="846" height="296" rx="16" fill="url(#about-bg)" stroke="url(#about-border)" stroke-width="1.5"/>
  <rect x="2" y="2" width="846" height="296" rx="16" fill="url(#about-grid)"/>

  <!-- Header -->
  <g class="about-font" transform="translate(44, 38)">
    <rect x="0" y="-8" width="4" height="22" rx="2" fill="url(#about-accent-line)"/>
    <text x="14" y="8" fill="#F5F7FB" font-size="16" font-weight="700" letter-spacing="1.5">ABOUT ME &amp; ENGINEERING APPROACH</text>
    <text x="14" y="26" fill="#8E9BB5" font-size="12" font-weight="500">Computer Science Undergraduate @ NIET, Greater Noida • Class of 2027</text>
  </g>

  <!-- Progress Bar Indicators (Carousel Segments: 4s each = 12s cycle) -->
  <g class="about-font" transform="translate(44, 86)">
    <!-- Segment 1 Track -->
    <rect x="0" y="0" width="240" height="4" rx="2" fill="#162238"/>
    <rect x="0" y="0" width="0" height="4" rx="2" fill="#247BFF" class="bar-c-1"/>
    <text x="0" y="18" fill="#93C5FD" font-size="10.5" font-weight="600" letter-spacing="0.5">01 / SOFTWARE ARCHITECTURE</text>

    <!-- Segment 2 Track -->
    <rect x="260" y="0" width="240" height="4" rx="2" fill="#162238"/>
    <rect x="260" y="0" width="0" height="4" rx="2" fill="#3B82F6" class="bar-c-2"/>
    <text x="260" y="18" fill="#93C5FD" font-size="10.5" font-weight="600" letter-spacing="0.5">02 / AI &amp; MACHINE LEARNING</text>

    <!-- Segment 3 Track -->
    <rect x="520" y="0" width="240" height="4" rx="2" fill="#162238"/>
    <rect x="520" y="0" width="0" height="4" rx="2" fill="#FF354F" class="bar-c-3"/>
    <text x="520" y="18" fill="#FCA5A5" font-size="10.5" font-weight="600" letter-spacing="0.5">03 / OPEN SOURCE &amp; DEVOPS</text>
  </g>

  <!-- Interactive Slide Stage (Swaps every 4s) -->
  <g class="about-font" transform="translate(44, 130)">
    <!-- SLIDE 1: Software Architecture -->
    <g class="slide-c-1">
      <rect x="0" y="0" width="762" height="98" rx="10" fill="#0C1428" stroke="#1D2E54" stroke-width="1"/>
      <circle cx="28" cy="28" r="12" fill="#152747"/>
      <text x="28" y="32" fill="#38BDF8" font-size="13" font-weight="700" text-anchor="middle">⚡</text>
      <text x="50" y="25" fill="#F1F5F9" font-size="15" font-weight="700">Robust Systems &amp; Clean Backend Architecture</text>
      <text x="50" y="44" fill="#94A3B8" font-size="12.5" font-weight="400">
        Dedicated to building resilient applications with Java, Spring Boot, and RESTful microservices.
      </text>
      <text x="50" y="62" fill="#94A3B8" font-size="12.5" font-weight="400">
        Prioritizing clean MVC separation, schema normalization, JPA/Hibernate queries, and scalable design.
      </text>
      <!-- Tag badges -->
      <g transform="translate(50, 72)">
        <text x="0" y="12" fill="#38BDF8" font-size="10.5" font-weight="600">CORE FOCUS:</text>
        <text x="80" y="12" fill="#CBD5E1" font-size="10.5" font-weight="500">Java • Spring Boot • REST APIs • MySQL • System Design</text>
      </g>
    </g>

    <!-- SLIDE 2: AI & Machine Learning -->
    <g class="slide-c-2">
      <rect x="0" y="0" width="762" height="98" rx="10" fill="#0C1428" stroke="#1D2E54" stroke-width="1"/>
      <circle cx="28" cy="28" r="12" fill="#152747"/>
      <text x="28" y="32" fill="#60A5FA" font-size="13" font-weight="700" text-anchor="middle">🧠</text>
      <text x="50" y="25" fill="#F1F5F9" font-size="15" font-weight="700">Applied Machine Learning &amp; AI Engineering</text>
      <text x="50" y="44" fill="#94A3B8" font-size="12.5" font-weight="400">
        Developing predictive machine learning models using LSTM neural networks, TensorFlow, and Scikit-learn.
      </text>
      <text x="50" y="62" fill="#94A3B8" font-size="12.5" font-weight="400">
        Investigating RAG workflows, LangChain integrations, FAISS embeddings, and intelligent data pipelines.
      </text>
      <!-- Tag badges -->
      <g transform="translate(50, 72)">
        <text x="0" y="12" fill="#60A5FA" font-size="10.5" font-weight="600">CORE FOCUS:</text>
        <text x="80" y="12" fill="#CBD5E1" font-size="10.5" font-weight="500">Python • TensorFlow • Keras • Scikit-learn • LangChain • RAG</text>
      </g>
    </g>

    <!-- SLIDE 3: Open Source & DevOps -->
    <g class="slide-c-3">
      <rect x="0" y="0" width="762" height="98" rx="10" fill="#0C1428" stroke="#2E1C2B" stroke-width="1"/>
      <circle cx="28" cy="28" r="12" fill="#2E1724"/>
      <text x="28" y="32" fill="#FF354F" font-size="13" font-weight="700" text-anchor="middle">🚀</text>
      <text x="50" y="25" fill="#F1F5F9" font-size="15" font-weight="700">Open Source Contributor &amp; DevOps Explorer</text>
      <text x="50" y="44" fill="#94A3B8" font-size="12.5" font-weight="400">
        Actively collaborating on open-source ecosystems (OpenMontage contributor, OpenSourceMatchmaker creator).
      </text>
      <text x="50" y="62" fill="#94A3B8" font-size="12.5" font-weight="400">
        Utilizing Git version control, Linux environments, Docker containerization, and AWS cloud services.
      </text>
      <!-- Tag badges -->
      <g transform="translate(50, 72)">
        <text x="0" y="12" fill="#FF354F" font-size="10.5" font-weight="600">CORE FOCUS:</text>
        <text x="80" y="12" fill="#CBD5E1" font-size="10.5" font-weight="500">Open Source • Docker • Linux CLI • Git &amp; GitHub • AWS</text>
      </g>
    </g>
  </g>

  <!-- Bottom Core Philosophy Bar -->
  <g class="about-font" transform="translate(44, 252)">
    <text x="0" y="16" fill="#64748B" font-size="11" font-weight="700" letter-spacing="1.5">LEARNING PHILOSOPHY:</text>
    
    <g transform="translate(160, 0)">
      <rect x="0" y="2" width="72" height="20" rx="4" fill="#10192E" stroke="#247BFF" stroke-width="1" stroke-opacity="0.4"/>
      <text x="36" y="16" fill="#93C5FD" font-size="10.5" font-weight="700" text-anchor="middle">1. BUILD</text>

      <text x="82" y="16" fill="#475569" font-size="12">→</text>

      <rect x="98" y="2" width="72" height="20" rx="4" fill="#10192E" stroke="#247BFF" stroke-width="1" stroke-opacity="0.4"/>
      <text x="134" y="16" fill="#93C5FD" font-size="10.5" font-weight="700" text-anchor="middle">2. LEARN</text>

      <text x="180" y="16" fill="#475569" font-size="12">→</text>

      <rect x="196" y="2" width="82" height="20" rx="4" fill="#10192E" stroke="#247BFF" stroke-width="1" stroke-opacity="0.4"/>
      <text x="237" y="16" fill="#93C5FD" font-size="10.5" font-weight="700" text-anchor="middle">3. IMPROVE</text>

      <text x="288" y="16" fill="#475569" font-size="12">→</text>

      <rect x="304" y="2" width="66" height="20" rx="4" fill="#24121C" stroke="#FF354F" stroke-width="1" stroke-opacity="0.5"/>
      <text x="337" y="16" fill="#FCA5A5" font-size="10.5" font-weight="700" text-anchor="middle">4. SHIP</text>
    </g>

    <text x="760" y="16" fill="#475569" font-size="11" font-weight="500" text-anchor="end">Auto-refresh: 4s / slide</text>
  </g>
</svg>`;

// 5. SVG C: stack.svg (Technology Ecosystem with 3 Orbits & Grouped Chips, 850x420)
const stackSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 850 420" width="100%" height="420" preserveAspectRatio="xMidYMid meet">
  <defs>
    <linearGradient id="stack-bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#070B16"/>
      <stop offset="100%" stop-color="#0B1226"/>
    </linearGradient>
    <linearGradient id="stack-border" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#247BFF" stop-opacity="0.75"/>
      <stop offset="50%" stop-color="#3B82F6" stop-opacity="0.2"/>
      <stop offset="100%" stop-color="#FF354F" stop-opacity="0.75"/>
    </linearGradient>
    <radialGradient id="stack-center-glow" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#247BFF" stop-opacity="0.4"/>
      <stop offset="50%" stop-color="#0A1021" stop-opacity="0.2"/>
      <stop offset="100%" stop-color="#070B16" stop-opacity="0"/>
    </radialGradient>
    <pattern id="stack-grid" width="24" height="24" patternUnits="userSpaceOnUse">
      <circle cx="2" cy="2" r="1" fill="#247BFF" fill-opacity="0.12"/>
    </pattern>
    <filter id="stack-node-glow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="3" result="blur"/>
      <feComposite in="SourceGraphic" in2="blur" operator="over"/>
    </filter>
  </defs>

  <style>
    @keyframes stack-orbit-1 {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    @keyframes stack-orbit-2 {
      0% { transform: rotate(360deg); }
      100% { transform: rotate(0deg); }
    }
    @keyframes stack-orbit-3 {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    @keyframes stack-pulse-core {
      0%, 100% { transform: scale(1); opacity: 0.9; }
      50% { transform: scale(1.06); opacity: 1; }
    }

    .stack-font { font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; }
    .orbit-g-1 { transform-origin: 660px 115px; animation: stack-orbit-1 24s linear infinite; }
    .orbit-g-2 { transform-origin: 660px 115px; animation: stack-orbit-2 36s linear infinite; }
    .orbit-g-3 { transform-origin: 660px 115px; animation: stack-orbit-3 48s linear infinite; }
    .core-pulse { transform-origin: 660px 115px; animation: stack-pulse-core 4s ease-in-out infinite; }

    @media (prefers-reduced-motion: reduce) {
      .orbit-g-1, .orbit-g-2, .orbit-g-3, .core-pulse { animation: none !important; }
    }
  </style>

  <!-- Base Frame -->
  <rect x="2" y="2" width="846" height="416" rx="16" fill="url(#stack-bg)" stroke="url(#stack-border)" stroke-width="1.5"/>
  <rect x="2" y="2" width="846" height="416" rx="16" fill="url(#stack-grid)"/>

  <!-- Left Header Section -->
  <g class="stack-font" transform="translate(44, 38)">
    <text x="0" y="0" fill="#247BFF" font-size="11" font-weight="700" letter-spacing="1.5">TECHNICAL ARSENAL</text>
    <text x="0" y="26" fill="#F5F7FB" font-size="22" font-weight="800" letter-spacing="-0.3">Technology Ecosystem</text>
    <text x="0" y="46" fill="#8E9BB5" font-size="12.5" font-weight="400">
      Categorized by proficiency: Core languages, backend architectures, AI &amp; cloud tooling.
    </text>
  </g>

  <!-- Right Visual: Tilted Planetary Orbital Rings -->
  <g>
    <!-- Core Ambient Glow -->
    <ellipse cx="660" cy="115" rx="120" ry="85" fill="url(#stack-center-glow)"/>

    <!-- Orbit 1: Inner (Backend & Languages) -->
    <ellipse cx="660" cy="115" rx="60" ry="38" stroke="#247BFF" stroke-width="1.2" stroke-dasharray="4 6" fill="none" opacity="0.6"/>
    <!-- Orbit 2: Middle (Web & Client) -->
    <ellipse cx="660" cy="115" rx="100" ry="60" stroke="#60A5FA" stroke-width="1.2" stroke-dasharray="6 8" fill="none" opacity="0.45"/>
    <!-- Orbit 3: Outer (AI, Cloud & Tools) -->
    <ellipse cx="660" cy="115" rx="140" ry="85" stroke="#FF354F" stroke-width="1.2" stroke-dasharray="8 10" fill="none" opacity="0.4"/>

    <!-- Revolving Satellites -->
    <!-- Orbit 1 Satellites -->
    <g class="orbit-g-1">
      <circle cx="720" cy="115" r="5" fill="#247BFF" filter="url(#stack-node-glow)"/>
      <circle cx="600" cy="115" r="4.5" fill="#38BDF8"/>
    </g>

    <!-- Orbit 2 Satellites -->
    <g class="orbit-g-2">
      <circle cx="660" cy="55" r="6" fill="#60A5FA" filter="url(#stack-node-glow)"/>
      <circle cx="760" cy="115" r="4" fill="#00FFB2"/>
      <circle cx="660" cy="175" r="5" fill="#3B82F6"/>
    </g>

    <!-- Orbit 3 Satellites -->
    <g class="orbit-g-3">
      <circle cx="800" cy="115" r="6" fill="#FF354F" filter="url(#stack-node-glow)"/>
      <circle cx="520" cy="115" r="5" fill="#F43F5E"/>
    </g>

    <!-- Central Hub Badge -->
    <g class="core-pulse">
      <circle cx="660" cy="115" r="28" fill="#0C1428" stroke="#247BFF" stroke-width="2"/>
      <circle cx="660" cy="115" r="22" fill="#132242"/>
      <text x="660" y="119" fill="#F8FAFC" font-family="ui-sans-serif, system-ui" font-size="11" font-weight="800" text-anchor="middle">YM-STACK</text>
    </g>
  </g>

  <!-- Divider Line -->
  <line x1="44" y1="188" x2="806" y2="188" stroke="#1E293B" stroke-width="1"/>

  <!-- Grouped Tech Skill Chips (6 Categories) -->
  <g class="stack-font" transform="translate(44, 204)">
    <!-- Column 1: Languages & Frontend -->
    <g transform="translate(0, 0)">
      <!-- Languages -->
      <text x="0" y="14" fill="#60A5FA" font-size="12" font-weight="700">PROGRAMMING LANGUAGES</text>
      <g transform="translate(0, 24)">
        <rect x="0" y="0" width="56" height="24" rx="5" fill="#131C31" stroke="#247BFF" stroke-width="1"/>
        <text x="28" y="16" fill="#E2E8F0" font-size="11" font-weight="600" text-anchor="middle">Java</text>

        <rect x="62" y="0" width="64" height="24" rx="5" fill="#131C31" stroke="#247BFF" stroke-width="1"/>
        <text x="94" y="16" fill="#E2E8F0" font-size="11" font-weight="600" text-anchor="middle">Python</text>

        <rect x="132" y="0" width="82" height="24" rx="5" fill="#131C31" stroke="#247BFF" stroke-width="1"/>
        <text x="173" y="16" fill="#E2E8F0" font-size="11" font-weight="600" text-anchor="middle">JavaScript</text>

        <rect x="220" y="0" width="50" height="24" rx="5" fill="#131C31" stroke="#247BFF" stroke-width="1"/>
        <text x="245" y="16" fill="#E2E8F0" font-size="11" font-weight="600" text-anchor="middle">SQL</text>

        <rect x="276" y="0" width="46" height="24" rx="5" fill="#131C31" stroke="#334155" stroke-width="1"/>
        <text x="299" y="16" fill="#94A3B8" font-size="11" font-weight="500" text-anchor="middle">C#</text>
      </g>

      <!-- Web Frontend -->
      <text x="0" y="74" fill="#38BDF8" font-size="12" font-weight="700">WEB DEVELOPMENT</text>
      <g transform="translate(0, 84)">
        <rect x="0" y="0" width="58" height="24" rx="5" fill="#131C31" stroke="#247BFF" stroke-width="1"/>
        <text x="29" y="16" fill="#E2E8F0" font-size="11" font-weight="600" text-anchor="middle">React</text>

        <rect x="64" y="0" width="86" height="24" rx="5" fill="#131C31" stroke="#247BFF" stroke-width="1"/>
        <text x="107" y="16" fill="#E2E8F0" font-size="11" font-weight="600" text-anchor="middle">TypeScript</text>

        <rect x="156" y="0" width="60" height="24" rx="5" fill="#131C31" stroke="#334155" stroke-width="1"/>
        <text x="186" y="16" fill="#CBD5E1" font-size="11" font-weight="500" text-anchor="middle">HTML5</text>

        <rect x="222" y="0" width="52" height="24" rx="5" fill="#131C31" stroke="#334155" stroke-width="1"/>
        <text x="248" y="16" fill="#CBD5E1" font-size="11" font-weight="500" text-anchor="middle">CSS3</text>

        <rect x="280" y="0" width="64" height="24" rx="5" fill="#131C31" stroke="#334155" stroke-width="1"/>
        <text x="312" y="16" fill="#CBD5E1" font-size="11" font-weight="500" text-anchor="middle">Tailwind</text>
      </g>

      <!-- Databases -->
      <text x="0" y="134" fill="#93C5FD" font-size="12" font-weight="700">DATABASES &amp; STORAGE</text>
      <g transform="translate(0, 144)">
        <rect x="0" y="0" width="62" height="24" rx="5" fill="#131C31" stroke="#247BFF" stroke-width="1"/>
        <text x="31" y="16" fill="#E2E8F0" font-size="11" font-weight="600" text-anchor="middle">MySQL</text>

        <rect x="68" y="0" width="76" height="24" rx="5" fill="#131C31" stroke="#334155" stroke-width="1"/>
        <text x="106" y="16" fill="#CBD5E1" font-size="11" font-weight="500" text-anchor="middle">MongoDB</text>

        <rect x="150" y="0" width="64" height="24" rx="5" fill="#131C31" stroke="#334155" stroke-width="1"/>
        <text x="182" y="16" fill="#CBD5E1" font-size="11" font-weight="500" text-anchor="middle">Oracle</text>
      </g>
    </g>

    <!-- Column 2: Backend, AI/ML, Cloud & Tools -->
    <g transform="translate(410, 0)">
      <!-- Backend -->
      <text x="0" y="14" fill="#34D399" font-size="12" font-weight="700">BACKEND &amp; APIS</text>
      <g transform="translate(0, 24)">
        <rect x="0" y="0" width="94" height="24" rx="5" fill="#131C31" stroke="#10B981" stroke-width="1" stroke-opacity="0.6"/>
        <text x="47" y="16" fill="#D1FAE5" font-size="11" font-weight="600" text-anchor="middle">Spring Boot</text>

        <rect x="100" y="0" width="76" height="24" rx="5" fill="#131C31" stroke="#10B981" stroke-width="1" stroke-opacity="0.6"/>
        <text x="138" y="16" fill="#D1FAE5" font-size="11" font-weight="600" text-anchor="middle">REST APIs</text>

        <rect x="182" y="0" width="64" height="24" rx="5" fill="#131C31" stroke="#334155" stroke-width="1"/>
        <text x="214" y="16" fill="#CBD5E1" font-size="11" font-weight="500" text-anchor="middle">FastAPI</text>

        <rect x="252" y="0" width="52" height="24" rx="5" fill="#131C31" stroke="#334155" stroke-width="1"/>
        <text x="278" y="16" fill="#CBD5E1" font-size="11" font-weight="500" text-anchor="middle">Flask</text>

        <rect x="310" y="0" width="82" height="24" rx="5" fill="#131C31" stroke="#334155" stroke-width="1"/>
        <text x="351" y="16" fill="#94A3B8" font-size="10.5" font-weight="500" text-anchor="middle">ASP.NET Core</text>
      </g>

      <!-- AI / ML -->
      <text x="0" y="74" fill="#F87171" font-size="12" font-weight="700">AI / MACHINE LEARNING</text>
      <g transform="translate(0, 84)">
        <rect x="0" y="0" width="84" height="24" rx="5" fill="#24131A" stroke="#FF354F" stroke-width="1"/>
        <text x="42" y="16" fill="#FECDD3" font-size="11" font-weight="600" text-anchor="middle">TensorFlow</text>

        <rect x="90" y="0" width="84" height="24" rx="5" fill="#24131A" stroke="#FF354F" stroke-width="1"/>
        <text x="132" y="16" fill="#FECDD3" font-size="11" font-weight="600" text-anchor="middle">Scikit-learn</text>

        <rect x="180" y="0" width="76" height="24" rx="5" fill="#1C182B" stroke="#818CF8" stroke-width="1"/>
        <text x="218" y="16" fill="#E0E7FF" font-size="11" font-weight="500" text-anchor="middle">LangChain</text>

        <rect x="262" y="0" width="52" height="24" rx="5" fill="#1C182B" stroke="#818CF8" stroke-width="1"/>
        <text x="288" y="16" fill="#E0E7FF" font-size="11" font-weight="500" text-anchor="middle">RAG</text>

        <rect x="320" y="0" width="72" height="24" rx="5" fill="#131C31" stroke="#334155" stroke-width="1"/>
        <text x="356" y="16" fill="#CBD5E1" font-size="10.5" font-weight="500" text-anchor="middle">Pandas/NP</text>
      </g>

      <!-- Cloud & Tools -->
      <text x="0" y="134" fill="#A78BFA" font-size="12" font-weight="700">CLOUD &amp; TOOLING</text>
      <g transform="translate(0, 144)">
        <rect x="0" y="0" width="52" height="24" rx="5" fill="#131C31" stroke="#247BFF" stroke-width="1"/>
        <text x="26" y="16" fill="#E2E8F0" font-size="11" font-weight="600" text-anchor="middle">AWS</text>

        <rect x="58" y="0" width="46" height="24" rx="5" fill="#131C31" stroke="#247BFF" stroke-width="1"/>
        <text x="81" y="16" fill="#E2E8F0" font-size="11" font-weight="600" text-anchor="middle">Git</text>

        <rect x="110" y="0" width="64" height="24" rx="5" fill="#131C31" stroke="#247BFF" stroke-width="1"/>
        <text x="142" y="16" fill="#E2E8F0" font-size="11" font-weight="600" text-anchor="middle">GitHub</text>

        <rect x="180" y="0" width="54" height="24" rx="5" fill="#131C31" stroke="#334155" stroke-width="1"/>
        <text x="207" y="16" fill="#CBD5E1" font-size="11" font-weight="500" text-anchor="middle">Linux</text>

        <rect x="240" y="0" width="62" height="24" rx="5" fill="#131C31" stroke="#334155" stroke-width="1"/>
        <text x="271" y="16" fill="#CBD5E1" font-size="11" font-weight="500" text-anchor="middle">Docker</text>
      </g>
    </g>
  </g>
</svg>`;

// 6. SVG D: id-dashboard.svg (Hanging ID Badge with Lanyard + HUD, 850x380)
const idDashboardSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 850 380" width="100%" height="380" preserveAspectRatio="xMidYMid meet">
  <defs>
    <linearGradient id="dash-bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#070B16"/>
      <stop offset="100%" stop-color="#090E1F"/>
    </linearGradient>
    <linearGradient id="dash-border" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#247BFF" stop-opacity="0.8"/>
      <stop offset="50%" stop-color="#3B82F6" stop-opacity="0.2"/>
      <stop offset="100%" stop-color="#FF354F" stop-opacity="0.8"/>
    </linearGradient>
    <linearGradient id="badge-sheen" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FFFFFF" stop-opacity="0.15"/>
      <stop offset="30%" stop-color="#FFFFFF" stop-opacity="0.02"/>
      <stop offset="70%" stop-color="#247BFF" stop-opacity="0.08"/>
      <stop offset="100%" stop-color="#FF354F" stop-opacity="0.15"/>
    </linearGradient>
    <linearGradient id="metal-clip" x1="0%" y1="0%" x2="0%" y2="1">
      <stop offset="0%" stop-color="#E2E8F0"/>
      <stop offset="50%" stop-color="#94A3B8"/>
      <stop offset="100%" stop-color="#64748B"/>
    </linearGradient>
    <clipPath id="dash-avatar-clip">
      <rect x="36" y="80" width="108" height="120" rx="8"/>
    </clipPath>
    <pattern id="dash-grid" width="20" height="20" patternUnits="userSpaceOnUse">
      <circle cx="2" cy="2" r="1" fill="#247BFF" fill-opacity="0.1"/>
    </pattern>
  </defs>

  <style>
    @keyframes dash-swing {
      0% { transform: translateY(-40px) rotate(0deg); }
      15% { transform: translateY(0px) rotate(-3.5deg); }
      30% { transform: translateY(0px) rotate(2.8deg); }
      45% { transform: translateY(0px) rotate(-2deg); }
      60% { transform: translateY(0px) rotate(1.8deg); }
      75% { transform: translateY(0px) rotate(-1.6deg); }
      100% { transform: translateY(0px) rotate(1.6deg); }
    }
    @keyframes dash-gentle-sway {
      0%, 100% { transform: rotate(-1.7deg); }
      50% { transform: rotate(1.7deg); }
    }
    @keyframes dash-laser-scan {
      0%, 100% { transform: translateY(0); opacity: 0.8; }
      50% { transform: translateY(22px); opacity: 0.3; }
    }
    @keyframes dash-sweep-sheen {
      0% { transform: translateX(-150px); }
      100% { transform: translateX(300px); }
    }

    .dash-font { font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; }
    .id-hanging-card {
      transform-origin: 180px 0px;
      animation: dash-swing 3.2s cubic-bezier(0.25, 1, 0.5, 1) 1 forwards, dash-gentle-sway 6s ease-in-out 3.2s infinite alternate;
    }
    .laser-beam { animation: dash-laser-scan 2.4s ease-in-out infinite; }

    @media (prefers-reduced-motion: reduce) {
      .id-hanging-card, .laser-beam { animation: none !important; transform: none !important; }
    }
  </style>

  <!-- Base Card Frame -->
  <rect x="2" y="2" width="846" height="376" rx="16" fill="url(#dash-bg)" stroke="url(#dash-border)" stroke-width="1.5"/>
  <rect x="2" y="2" width="846" height="376" rx="16" fill="url(#dash-grid)"/>

  <!-- LEFT: HANGING PHYSICAL ID BADGE -->
  <g class="id-hanging-card" transform="translate(48, 0)">
    <!-- Lanyard Strap hanging down from top edge -->
    <path d="M 120 0 L 126 38 L 134 38 L 140 0 Z" fill="#0F172A" stroke="#247BFF" stroke-width="1"/>
    <!-- Metallic Ring / Clasp -->
    <rect x="122" y="36" width="16" height="18" rx="3" fill="url(#metal-clip)"/>
    <ellipse cx="130" cy="54" rx="8" ry="4" fill="#334155"/>
    <path d="M 125 54 L 125 66 L 135 66 L 135 54" stroke="url(#metal-clip)" stroke-width="3" fill="none"/>

    <!-- ID Badge Holder Body -->
    <g transform="translate(0, 68)">
      <!-- Outer Plastic Sleeve -->
      <rect x="10" y="0" width="240" height="280" rx="12" fill="#0C1324" stroke="#247BFF" stroke-width="2"/>
      <!-- Metallic Sheen Overlay -->
      <rect x="10" y="0" width="240" height="280" rx="12" fill="url(#badge-sheen)"/>

      <!-- Clip Slot Cutout -->
      <rect x="110" y="8" width="40" height="8" rx="4" fill="#070B16" stroke="#1E293B" stroke-width="1"/>

      <!-- Header Strip -->
      <rect x="18" y="24" width="224" height="28" rx="6" fill="#132142"/>
      <circle cx="34" cy="38" r="5" fill="#247BFF"/>
      <text x="46" y="42" fill="#F8FAFC" class="dash-font" font-size="11" font-weight="800" letter-spacing="1">ENGINEERING ACCESS</text>
      <text x="210" y="42" fill="#88E7D2" class="dash-font" font-size="10" font-weight="700">ACTIVE</text>

      <!-- Inlined Portrait Box -->
      <rect x="24" y="60" width="94" height="106" rx="8" fill="#070B16" stroke="#247BFF" stroke-width="1.5"/>
      <image href="${idBase64}" x="22" y="58" width="98" height="110" preserveAspectRatio="xMidYMid slice" clip-path="url(#dash-avatar-clip)"/>

      <!-- Portrait corner brackets -->
      <path d="M 26 68 L 26 62 L 32 62" stroke="#247BFF" stroke-width="2" fill="none"/>
      <path d="M 116 68 L 116 62 L 110 62" stroke="#FF354F" stroke-width="2" fill="none"/>
      <path d="M 26 160 L 26 164 L 32 164" stroke="#247BFF" stroke-width="2" fill="none"/>
      <path d="M 116 160 L 116 164 L 110 164" stroke="#FF354F" stroke-width="2" fill="none"/>

      <!-- Right of Photo Info -->
      <g class="dash-font" transform="translate(126, 68)">
        <text x="0" y="10" fill="#64748B" font-size="9" font-weight="700" letter-spacing="0.5">DEV ID</text>
        <text x="0" y="24" fill="#F1F5F9" font-size="12" font-weight="800">YM-630</text>

        <text x="0" y="42" fill="#64748B" font-size="9" font-weight="700" letter-spacing="0.5">ROLE</text>
        <text x="0" y="54" fill="#93C5FD" font-size="10.5" font-weight="700">Software Dev</text>
        <text x="0" y="66" fill="#CBD5E1" font-size="9.5" font-weight="500">AI / Cloud</text>

        <text x="0" y="84" fill="#64748B" font-size="9" font-weight="700" letter-spacing="0.5">BATCH</text>
        <text x="0" y="98" fill="#88E7D2" font-size="11" font-weight="700">2023 - 2027</text>
      </g>

      <!-- Developer Full Name -->
      <g class="dash-font" transform="translate(24, 184)">
        <text x="0" y="0" fill="#F8FAFC" font-size="16" font-weight="800" letter-spacing="0.5">YOGENDRA MAURYA</text>
        <text x="0" y="14" fill="#8E9BB5" font-size="10.5" font-weight="500">NIET, Greater Noida • B.Tech CSE</text>
      </g>

      <!-- Barcode Graphic with Laser Scanner -->
      <g transform="translate(24, 214)">
        <!-- Barcode Lines -->
        <rect x="0" y="0" width="3" height="30" fill="#94A3B8"/>
        <rect x="5" y="0" width="2" height="30" fill="#94A3B8"/>
        <rect x="9" y="0" width="4" height="30" fill="#94A3B8"/>
        <rect x="16" y="0" width="2" height="30" fill="#94A3B8"/>
        <rect x="20" y="0" width="5" height="30" fill="#94A3B8"/>
        <rect x="28" y="0" width="2" height="30" fill="#94A3B8"/>
        <rect x="33" y="0" width="3" height="30" fill="#94A3B8"/>
        <rect x="38" y="0" width="1" height="30" fill="#94A3B8"/>
        <rect x="42" y="0" width="6" height="30" fill="#94A3B8"/>
        <rect x="51" y="0" width="2" height="30" fill="#94A3B8"/>
        <rect x="56" y="0" width="4" height="30" fill="#94A3B8"/>
        <rect x="63" y="0" width="2" height="30" fill="#94A3B8"/>
        <rect x="68" y="0" width="5" height="30" fill="#94A3B8"/>
        <rect x="76" y="0" width="2" height="30" fill="#94A3B8"/>
        <rect x="81" y="0" width="3" height="30" fill="#94A3B8"/>
        <rect x="87" y="0" width="4" height="30" fill="#94A3B8"/>
        <rect x="94" y="0" width="1" height="30" fill="#94A3B8"/>
        <rect x="98" y="0" width="5" height="30" fill="#94A3B8"/>
        <rect x="106" y="0" width="2" height="30" fill="#94A3B8"/>
        <rect x="111" y="0" width="4" height="30" fill="#94A3B8"/>
        <rect x="118" y="0" width="2" height="30" fill="#94A3B8"/>
        <rect x="123" y="0" width="5" height="30" fill="#94A3B8"/>
        <rect x="131" y="0" width="2" height="30" fill="#94A3B8"/>
        <rect x="136" y="0" width="3" height="30" fill="#94A3B8"/>
        <rect x="142" y="0" width="4" height="30" fill="#94A3B8"/>
        <rect x="149" y="0" width="2" height="30" fill="#94A3B8"/>
        <rect x="154" y="0" width="5" height="30" fill="#94A3B8"/>
        <rect x="162" y="0" width="2" height="30" fill="#94A3B8"/>
        <rect x="167" y="0" width="4" height="30" fill="#94A3B8"/>
        <rect x="174" y="0" width="3" height="30" fill="#94A3B8"/>
        <rect x="180" y="0" width="2" height="30" fill="#94A3B8"/>
        <rect x="185" y="0" width="5" height="30" fill="#94A3B8"/>
        <rect x="193" y="0" width="3" height="30" fill="#94A3B8"/>
        <rect x="199" y="0" width="2" height="30" fill="#94A3B8"/>
        <rect x="204" y="0" width="5" height="30" fill="#94A3B8"/>

        <!-- Laser Scanner Bar (Animates down) -->
        <line x1="0" y1="4" x2="212" y2="4" stroke="#FF354F" stroke-width="2" class="laser-beam"/>
        <!-- Barcode Human Text -->
        <text x="106" y="44" fill="#64748B" class="dash-font" font-size="8.5" font-weight="600" text-anchor="middle" letter-spacing="3">630 - 2027 - IN - NIET</text>
      </g>
    </g>
  </g>

  <!-- RIGHT: VERIFIED DEVELOPER DASHBOARD HUD -->
  <g class="dash-font" transform="translate(340, 42)">
    <!-- Header -->
    <text x="0" y="0" fill="#247BFF" font-size="11" font-weight="700" letter-spacing="1.5">VERIFIED PROFILE METRICS</text>
    <text x="0" y="26" fill="#F8FAFC" font-size="22" font-weight="800" letter-spacing="-0.3">Developer Identity &amp; Status</text>

    <!-- 4 HUD Stat Cards Grid -->
    <g transform="translate(0, 44)">
      <!-- Card 1: Repositories -->
      <rect x="0" y="0" width="220" height="74" rx="10" fill="#0C1428" stroke="#1D2A4A" stroke-width="1"/>
      <circle cx="24" cy="24" r="10" fill="#152648"/>
      <text x="24" y="28" fill="#60A5FA" font-size="12" text-anchor="middle">📦</text>
      <text x="44" y="22" fill="#8E9BB5" font-size="11" font-weight="600">PUBLIC REPOSITORIES</text>
      <text x="44" y="48" fill="#F8FAFC" font-size="24" font-weight="800">10</text>
      <text x="80" y="48" fill="#88E7D2" font-size="11" font-weight="600">Verified on GitHub</text>

      <!-- Card 2: Academic Status -->
      <rect x="236" y="0" width="230" height="74" rx="10" fill="#0C1428" stroke="#1D2A4A" stroke-width="1"/>
      <circle cx="260" cy="24" r="10" fill="#152648"/>
      <text x="260" y="28" fill="#38BDF8" font-size="12" text-anchor="middle">🎓</text>
      <text x="280" y="22" fill="#8E9BB5" font-size="11" font-weight="600">EDUCATION &amp; BATCH</text>
      <text x="280" y="46" fill="#F8FAFC" font-size="16" font-weight="800">B.Tech CSE '27</text>
      <text x="280" y="62" fill="#94A3B8" font-size="11" font-weight="500">NIET, Greater Noida</text>

      <!-- Card 3: Core Competencies -->
      <rect x="0" y="86" width="220" height="74" rx="10" fill="#0C1428" stroke="#1D2A4A" stroke-width="1"/>
      <circle cx="24" cy="110" r="10" fill="#152648"/>
      <text x="24" y="114" fill="#34D399" font-size="12" text-anchor="middle">⚡</text>
      <text x="44" y="108" fill="#8E9BB5" font-size="11" font-weight="600">PRIMARY FOCUS</text>
      <text x="44" y="130" fill="#F8FAFC" font-size="15" font-weight="700">Backend &amp; Cloud</text>
      <text x="44" y="146" fill="#88E7D2" font-size="11" font-weight="500">Java • Python • Spring</text>

      <!-- Card 4: Open Source & AI -->
      <rect x="236" y="86" width="230" height="74" rx="10" fill="#0C1428" stroke="#2B1522" stroke-width="1"/>
      <circle cx="260" cy="110" r="10" fill="#2B1420"/>
      <text x="260" y="114" fill="#FF354F" font-size="12" text-anchor="middle">🔥</text>
      <text x="280" y="108" fill="#8E9BB5" font-size="11" font-weight="600">RESEARCH &amp; COMMITS</text>
      <text x="280" y="130" fill="#F8FAFC" font-size="15" font-weight="700">AI / ML &amp; Open Source</text>
      <text x="280" y="146" fill="#FCA5A5" font-size="11" font-weight="500">LSTM • RAG • PR Contributor</text>
    </g>

    <!-- Bottom Mission Statement -->
    <g transform="translate(0, 222)">
      <rect x="0" y="0" width="466" height="52" rx="8" fill="#10182C" stroke="#247BFF" stroke-width="1" stroke-opacity="0.3"/>
      <text x="16" y="22" fill="#64748B" font-size="10" font-weight="700" letter-spacing="1">CAREER GOAL &amp; COMMITMENT</text>
      <text x="16" y="38" fill="#CBD5E1" font-size="12" font-weight="500">
        "Build practical software products, learn modern tech, and ship reliable, scalable code."
      </text>
    </g>
  </g>
</svg>`;

// 7. SVG E: connect.svg (Pointing Character on Left + Social Cards on Right, 850x300)
const connectSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 850 300" width="100%" height="300" preserveAspectRatio="xMidYMid meet">
  <defs>
    <linearGradient id="conn-bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#070B16"/>
      <stop offset="100%" stop-color="#0A1024"/>
    </linearGradient>
    <linearGradient id="conn-border" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#247BFF" stop-opacity="0.8"/>
      <stop offset="50%" stop-color="#3B82F6" stop-opacity="0.2"/>
      <stop offset="100%" stop-color="#FF354F" stop-opacity="0.8"/>
    </linearGradient>
    <radialGradient id="conn-glow" cx="20%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#247BFF" stop-opacity="0.25"/>
      <stop offset="100%" stop-color="#070B16" stop-opacity="0"/>
    </radialGradient>
    <pattern id="conn-grid" width="20" height="20" patternUnits="userSpaceOnUse">
      <circle cx="2" cy="2" r="1" fill="#247BFF" fill-opacity="0.1"/>
    </pattern>
  </defs>

  <style>
    @keyframes conn-gentle-bob {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-4px); }
    }
    @keyframes conn-beam-pulse {
      0%, 100% { opacity: 0.3; transform: scaleX(0.95); }
      50% { opacity: 0.8; transform: scaleX(1.05); }
    }

    .conn-font { font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; }
    .conn-char { animation: conn-gentle-bob 5s ease-in-out infinite; }
    .conn-beam { transform-origin: 340px 150px; animation: conn-beam-pulse 3s ease-in-out infinite; }

    @media (prefers-reduced-motion: reduce) {
      .conn-char, .conn-beam { animation: none !important; transform: none !important; }
    }
  </style>

  <!-- Card Frame -->
  <rect x="2" y="2" width="846" height="296" rx="16" fill="url(#conn-bg)" stroke="url(#conn-border)" stroke-width="1.5"/>
  <rect x="2" y="2" width="846" height="296" rx="16" fill="url(#conn-grid)"/>

  <!-- Character on Left Pointing Rightward -->
  <g class="conn-char" transform="translate(10, 8)">
    <image href="${ptBase64}" x="-10" y="10" width="370" height="278" preserveAspectRatio="xMidYMid meet"/>
    <!-- Subtle Pointer Energy Beam -->
    <path d="M 330 190 Q 380 185 415 150" stroke="#247BFF" stroke-width="2" stroke-dasharray="4 6" fill="none" class="conn-beam"/>
    <circle cx="415" cy="150" r="3.5" fill="#247BFF"/>
  </g>

  <!-- Right Side: Contact & Collaboration Info -->
  <g class="conn-font" transform="translate(390, 36)">
    <!-- Header -->
    <text x="0" y="0" fill="#247BFF" font-size="11" font-weight="700" letter-spacing="1.5">LET'S CONNECT &amp; COLLABORATE</text>
    <text x="0" y="26" fill="#F8FAFC" font-size="22" font-weight="800" letter-spacing="-0.3">Get In Touch</text>
    <text x="0" y="44" fill="#8E9BB5" font-size="12" font-weight="400">
      Always excited to discuss software engineering, open-source work, and internship opportunities.
    </text>

    <!-- Contact Cards Column -->
    <g transform="translate(0, 62)">
      <!-- GitHub Card -->
      <g transform="translate(0, 0)">
        <rect x="0" y="0" width="410" height="48" rx="8" fill="#0C1428" stroke="#1E2A4A" stroke-width="1"/>
        <!-- GitHub Mark -->
        <circle cx="26" cy="24" r="14" fill="#142142"/>
        <path d="M 26 14 C 20.48 14 16 18.48 16 24 C 16 28.42 18.87 32.17 22.84 33.49 C 23.34 33.58 23.52 33.27 23.52 33 C 23.52 32.77 23.51 32.14 23.51 31.33 C 20.73 31.93 20.14 30 20.14 30 C 19.68 28.85 19.03 28.54 19.03 28.54 C 18.12 27.92 19.1 27.93 19.1 27.93 C 20.11 28 20.64 28.97 20.64 28.97 C 21.53 30.5 22.98 30.06 23.55 29.8 C 23.64 29.15 23.9 28.71 24.19 28.46 C 21.97 28.21 19.64 27.35 19.64 23.52 C 19.64 22.43 20.03 21.54 20.67 20.84 C 20.57 20.59 20.23 19.57 20.77 18.2 C 20.77 18.2 21.61 17.93 23.52 19.22 C 24.32 19 25.17 18.89 26.02 18.89 C 26.87 18.89 27.72 19 28.52 19.22 C 30.43 17.93 31.27 18.2 31.27 18.2 C 31.81 19.57 31.47 20.59 31.37 20.84 C 32.01 21.54 32.4 22.43 32.4 23.52 C 32.4 27.36 30.06 28.21 27.83 28.46 C 28.19 28.77 28.51 29.39 28.51 30.33 C 28.51 31.68 28.5 32.76 28.5 33 C 28.5 33.27 28.68 33.59 29.19 33.49 C 33.16 32.16 36.02 28.42 36.02 24 C 36.02 18.48 31.54 14 26.02 14 Z" fill="#F8FAFC"/>
        <text x="50" y="21" fill="#F8FAFC" font-size="12.5" font-weight="700">GitHub Profile</text>
        <text x="50" y="35" fill="#8E9BB5" font-size="11" font-weight="500">github.com/Yogendra630</text>
        <text x="390" y="28" fill="#38BDF8" font-size="11" font-weight="600" text-anchor="end">@Yogendra630 ↗</text>
      </g>

      <!-- LinkedIn Card -->
      <g transform="translate(0, 56)">
        <rect x="0" y="0" width="410" height="48" rx="8" fill="#0C1428" stroke="#1E2A4A" stroke-width="1"/>
        <!-- LinkedIn Mark -->
        <circle cx="26" cy="24" r="14" fill="#0A66C2"/>
        <text x="26" y="29" fill="#FFFFFF" font-size="14" font-weight="800" text-anchor="middle">in</text>
        <text x="50" y="21" fill="#F8FAFC" font-size="12.5" font-weight="700">LinkedIn Profile</text>
        <text x="50" y="35" fill="#8E9BB5" font-size="11" font-weight="500">linkedin.com/in/yogendra-maurya-04a510288</text>
        <text x="390" y="28" fill="#60A5FA" font-size="11" font-weight="600" text-anchor="end">Connect ↗</text>
      </g>

      <!-- Open For Opportunities Banner -->
      <g transform="translate(0, 112)">
        <rect x="0" y="0" width="410" height="40" rx="6" fill="#141E33" stroke="#247BFF" stroke-width="1" stroke-opacity="0.3"/>
        <circle cx="20" cy="20" r="4" fill="#00FFB2"/>
        <text x="32" y="24" fill="#88E7D2" font-size="11" font-weight="700">LOOKING FOR:</text>
        <text x="126" y="24" fill="#CBD5E1" font-size="11" font-weight="500">Software Engineering &amp; Backend Internships</text>
      </g>
    </g>
  </g>
</svg>`;

// Write all SVGs to Yogendra630/assets and public/assets
const svgs = [
  { name: 'hero.svg', content: heroSvg },
  { name: 'about-life.svg', content: aboutLifeSvg },
  { name: 'stack.svg', content: stackSvg },
  { name: 'id-dashboard.svg', content: idDashboardSvg },
  { name: 'connect.svg', content: connectSvg }
];

svgs.forEach(({ name, content }) => {
  fs.writeFileSync(path.join(assetsDir, name), content, 'utf8');
  fs.writeFileSync(path.join(publicAssetsDir, name), content, 'utf8');
  console.log(`Saved ${name} (${content.length} bytes)`);
});

// 8. Generate README_PREVIEW.png (Composite of the entire README experience)
console.log('Rendering README_PREVIEW.png composite image...');
const previewSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 1480" width="1200" height="1480">
  <defs>
    <linearGradient id="prev-bg" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#05070E"/>
      <stop offset="100%" stop-color="#0A0E1A"/>
    </linearGradient>
  </defs>
  <rect width="1200" height="1480" fill="url(#prev-bg)"/>

  <!-- GitHub Header mockup -->
  <g transform="translate(60, 40)">
    <rect width="1080" height="48" rx="8" fill="#0D1117" stroke="#30363D" stroke-width="1"/>
    <circle cx="24" cy="24" r="6" fill="#F85149"/>
    <circle cx="44" cy="24" r="6" fill="#E3B341"/>
    <circle cx="64" cy="24" r="6" fill="#2EA043"/>
    <text x="94" y="29" fill="#8B949E" font-family="ui-sans-serif, system-ui" font-size="13" font-weight="600">github.com/Yogendra630 / Yogendra630 / README.md</text>
  </g>

  <!-- SVG 1: Hero -->
  <g transform="translate(175, 110) scale(1)">
    ${heroSvg}
  </g>

  <!-- SVG 2: About -->
  <g transform="translate(175, 490) scale(1)">
    ${aboutLifeSvg}
  </g>

  <!-- SVG 3: Stack -->
  <g transform="translate(175, 810) scale(1)">
    ${stackSvg}
  </g>

  <!-- SVG 4: Dashboard -->
  <g transform="translate(175, 1250) scale(1)">
    ${idDashboardSvg}
  </g>
</svg>`;

const resvgPrev = new Resvg(previewSvg, { fitTo: { mode: 'width', value: 1200 } });
const previewPngBuffer = resvgPrev.render().asPng();
fs.writeFileSync(path.join(outDir, 'README_PREVIEW.png'), previewPngBuffer);
fs.writeFileSync(path.join(rootDir, 'public', 'README_PREVIEW.png'), previewPngBuffer);
console.log(`Saved README_PREVIEW.png (${previewPngBuffer.length} bytes)`);

// 9. Generate README.md
const readmeMd = `# Hi, I'm Yogendra Maurya 👋

<div align="center">

![Introduction](./assets/hero.svg?v=1)

![About Me](./assets/about-life.svg?v=1)

![Technology Stack](./assets/stack.svg?v=1)

</div>

## 🚀 Featured Projects

A curated selection of real, verified repositories developed to solve practical problems in backend architecture, machine learning, and cloud workflows:

| Project | Description | Technologies | Repository |
| :--- | :--- | :--- | :--- |
| **[SmartContactManager](https://github.com/Yogendra630/SmartContactManager)** | Full-stack contact management application with secure authentication, contact CRUD, pagination, and cloud storage. | Java, Spring Boot, MySQL, MVC, Tailwind CSS | [View Repository ↗](https://github.com/Yogendra630/SmartContactManager) |
| **[Stock Price Prediction ML](https://github.com/Yogendra630/stock-price-prediction-ml)** | Time-series stock trend forecasting system using Deep Learning Long Short-Term Memory (LSTM) recurrent networks. | Python, TensorFlow, Keras, yfinance, Streamlit | [View Repository ↗](https://github.com/Yogendra630/stock-price-prediction-ml) |
| **[OpenSource Matchmaker](https://github.com/Yogendra630/OpenSourceMatchmaker)** | GitHub developer project discovery platform matching open-source opportunities to user language skills. | TypeScript, React, GitHub REST API, Vite | [View Repository ↗](https://github.com/Yogendra630/OpenSourceMatchmaker) |
| **[CloudDocs](https://github.com/Yogendra630/cloud-Docs)** | Collaborative cloud document workspace with real-time editing, document organization, and clean UI. | TypeScript, React, Cloud Architecture | [View Repository ↗](https://github.com/Yogendra630/cloud-Docs) |
| **[GitHub Profile Analyzer](https://github.com/Yogendra630/github-profile-analyzer)** | Interactive repository & profile analytics engine featuring commit breakdown, charts, and velocity statistics. | JavaScript, React, Chart.js, GitHub API | [View Repository ↗](https://github.com/Yogendra630/github-profile-analyzer) |

<br/>

<div align="center">

![Developer Identity](./assets/id-dashboard.svg?v=1)

![Connect](./assets/connect.svg?v=1)

</div>

## 🌐 Let's Connect

Direct verified links to connect with me:

- **GitHub:** [@Yogendra630](https://github.com/Yogendra630)
- **LinkedIn:** [linkedin.com/in/yogendra-maurya-04a510288](https://www.linkedin.com/in/yogendra-maurya-04a510288/)

<br/>

<div align="center">
  <sub>⚡ <b>Build. Learn. Ship. Repeat.</b> ⚡</sub>
</div>
`;

fs.writeFileSync(path.join(outDir, 'README.md'), readmeMd, 'utf8');
console.log('Saved README.md');

// 10. Generate preview.html
const previewHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Yogendra Maurya - GitHub Profile README Preview</title>
  <style>
    :root {
      --bg: #0d1117;
      --card-bg: #161b22;
      --border: #30363d;
      --text: #c9d1d9;
      --heading: #f0f6fc;
      --accent: #58a6ff;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background: var(--bg);
      color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
      line-height: 1.6;
      padding: 32px 16px;
    }
    .container {
      max-width: 890px;
      margin: 0 auto;
      background: var(--bg);
      border: 1px solid var(--border);
      border-radius: 10px;
      padding: 32px;
    }
    .header-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 1px solid var(--border);
      padding-bottom: 16px;
      margin-bottom: 24px;
    }
    .badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: #1f6feb26;
      color: var(--accent);
      border: 1px solid #1f6feb66;
      padding: 4px 10px;
      border-radius: 12px;
      font-size: 12px;
      font-weight: 600;
    }
    h1, h2, h3 { color: var(--heading); margin: 24px 0 16px; }
    img { max-width: 100%; height: auto; display: block; margin: 16px auto; border-radius: 12px; }
    table {
      width: 100%;
      border-collapse: collapse;
      margin: 20px 0;
      font-size: 14px;
    }
    th, td {
      border: 1px solid var(--border);
      padding: 12px 14px;
      text-align: left;
    }
    th { background: var(--card-bg); color: var(--heading); }
    a { color: var(--accent); text-decoration: none; }
    a:hover { text-decoration: underline; }
    .footer {
      text-align: center;
      margin-top: 32px;
      padding-top: 20px;
      border-top: 1px solid var(--border);
      color: #8b949e;
      font-size: 13px;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header-bar">
      <div>
        <span class="badge">Yogendra630 / README.md</span>
      </div>
      <div style="font-size: 12px; color: #8b949e;">
        GitHub Profile Suite • 5 Animated SVGs
      </div>
    </div>

    <img src="./assets/hero.svg?v=1" alt="Introduction">

    <img src="./assets/about-life.svg?v=1" alt="About Me">

    <img src="./assets/stack.svg?v=1" alt="Technology Stack">

    <h2>🚀 Featured Projects</h2>
    <table>
      <thead>
        <tr>
          <th>Project</th>
          <th>Description</th>
          <th>Technologies</th>
          <th>Repository</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><strong>SmartContactManager</strong></td>
          <td>Full-stack contact management application with secure authentication, contact CRUD, pagination, and cloud storage.</td>
          <td>Java, Spring Boot, MySQL, MVC, Tailwind CSS</td>
          <td><a href="https://github.com/Yogendra630/SmartContactManager" target="_blank" rel="noreferrer">View Repository ↗</a></td>
        </tr>
        <tr>
          <td><strong>Stock Price Prediction ML</strong></td>
          <td>Time-series stock trend forecasting system using Deep Learning Long Short-Term Memory (LSTM) recurrent networks.</td>
          <td>Python, TensorFlow, Keras, yfinance, Streamlit</td>
          <td><a href="https://github.com/Yogendra630/stock-price-prediction-ml" target="_blank" rel="noreferrer">View Repository ↗</a></td>
        </tr>
        <tr>
          <td><strong>OpenSource Matchmaker</strong></td>
          <td>GitHub developer project discovery platform matching open-source opportunities to user language skills.</td>
          <td>TypeScript, React, GitHub REST API, Vite</td>
          <td><a href="https://github.com/Yogendra630/OpenSourceMatchmaker" target="_blank" rel="noreferrer">View Repository ↗</a></td>
        </tr>
        <tr>
          <td><strong>CloudDocs</strong></td>
          <td>Collaborative cloud document workspace with real-time editing, document organization, and clean UI.</td>
          <td>TypeScript, React, Cloud Architecture</td>
          <td><a href="https://github.com/Yogendra630/cloud-Docs" target="_blank" rel="noreferrer">View Repository ↗</a></td>
        </tr>
        <tr>
          <td><strong>GitHub Profile Analyzer</strong></td>
          <td>Interactive repository & profile analytics engine featuring commit breakdown, charts, and velocity statistics.</td>
          <td>JavaScript, React, Chart.js, GitHub API</td>
          <td><a href="https://github.com/Yogendra630/github-profile-analyzer" target="_blank" rel="noreferrer">View Repository ↗</a></td>
        </tr>
      </tbody>
    </table>

    <img src="./assets/id-dashboard.svg?v=1" alt="Developer Identity">

    <img src="./assets/connect.svg?v=1" alt="Connect">

    <h2>🌐 Let's Connect</h2>
    <ul>
      <li><strong>GitHub:</strong> <a href="https://github.com/Yogendra630" target="_blank" rel="noreferrer">@Yogendra630</a></li>
      <li><strong>LinkedIn:</strong> <a href="https://www.linkedin.com/in/yogendra-maurya-04a510288/" target="_blank" rel="noreferrer">linkedin.com/in/yogendra-maurya-04a510288</a></li>
    </ul>

    <div class="footer">
      ⚡ <strong>Build. Learn. Ship. Repeat.</strong> ⚡
    </div>
  </div>
</body>
</html>`;

fs.writeFileSync(path.join(outDir, 'preview.html'), previewHtml, 'utf8');
console.log('Saved preview.html');

// 11. Generate LICENSES/ASSET_LICENSES.md
const licensesMd = `# Asset & Design Licenses

## Overview
This document outlines the licensing, copyright, and provenance for all assets contained within the \`Yogendra630\` animated GitHub Profile README suite.

---

### 1. Vector Illustrations & Character Assets
- **\`assets/id.png\`**
  - **Type:** Illustrated Character Portrait (Chest-upward)
  - **Subject:** Yogendra Maurya
  - **License:** Permissive Custom Open Source License / Personal Developer License for Yogendra Maurya. Free to use, adapt, and distribute for personal branding, resumes, and portfolios.
- **\`assets/right_pointing.png\`**
  - **Type:** Illustrated Character Gesture (Waist-upward, pointing rightward)
  - **Subject:** Yogendra Maurya
  - **License:** Permissive Custom Open Source License / Personal Developer License for Yogendra Maurya.

---

### 2. Animated SVG Files
- **\`assets/hero.svg\`**
- **\`assets/about-life.svg\`**
- **\`assets/stack.svg\`**
- **\`assets/id-dashboard.svg\`**
- **\`assets/connect.svg\`**
  - **Author:** Handcrafted modular SVG suite with pure CSS keyframe animations.
  - **Dependencies:** Self-contained SVG elements. No external scripts or foreignObjects.
  - **License:** MIT License. Free to modify, inspect, and deploy.

---

### 3. Typography & System Fonts
- All SVGs employ standard cross-platform system font stacks (\`ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif\`).
- No commercial proprietary font files are embedded or required.

---

### 4. Brand Icons & Logos
- Technology labels (Java, Python, Spring Boot, React, MySQL, AWS, etc.) refer to their respective open-source projects or registered trademarks.
- Mentioned strictly under nominative fair use for technical skill identification and developer portfolio representation.
`;

fs.writeFileSync(path.join(licensesDir, 'ASSET_LICENSES.md'), licensesMd, 'utf8');
console.log('Saved LICENSES/ASSET_LICENSES.md');

// 12. Create ZIP archive
console.log('Packaging complete Yogendra630.zip...');
const zip = new JSZip();
const folder = zip.folder('Yogendra630');

folder.file('README.md', readmeMd);
folder.file('preview.html', previewHtml);
folder.file('README_PREVIEW.png', previewPngBuffer);

const assetsFolder = folder.folder('assets');
assetsFolder.file('id.png', idPngBuffer);
assetsFolder.file('right_pointing.png', ptPngBuffer);
assetsFolder.file('hero.svg', heroSvg);
assetsFolder.file('about-life.svg', aboutLifeSvg);
assetsFolder.file('stack.svg', stackSvg);
assetsFolder.file('id-dashboard.svg', idDashboardSvg);
assetsFolder.file('connect.svg', connectSvg);

const licFolder = folder.folder('LICENSES');
licFolder.file('ASSET_LICENSES.md', licensesMd);

const zipContent = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
fs.writeFileSync(path.join(rootDir, 'Yogendra630.zip'), zipContent);
fs.writeFileSync(path.join(rootDir, 'public', 'Yogendra630.zip'), zipContent);
console.log(`Saved Yogendra630.zip (${zipContent.length} bytes)`);

console.log('Asset generation completed successfully!');
