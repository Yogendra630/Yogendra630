import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { Resvg } from '@resvg/resvg-js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const outDir = path.join(rootDir, 'Yogendra630');
const assetsDir = path.join(outDir, 'assets');

console.log('=== RUNNING COMPREHENSIVE QA & VALIDATION SUITE ===\n');

const requiredFiles = [
  path.join(outDir, 'README.md'),
  path.join(outDir, 'preview.html'),
  path.join(outDir, 'README_PREVIEW.png'),
  path.join(outDir, 'LICENSES', 'ASSET_LICENSES.md'),
  path.join(assetsDir, 'id.png'),
  path.join(assetsDir, 'right_pointing.png'),
  path.join(assetsDir, 'hero.svg'),
  path.join(assetsDir, 'about-life.svg'),
  path.join(assetsDir, 'stack.svg'),
  path.join(assetsDir, 'id-dashboard.svg'),
  path.join(assetsDir, 'connect.svg'),
  path.join(rootDir, 'Yogendra630.zip'),
];

let allPassed = true;

// 1. File existence check
console.log('Test 1: Required files check:');
requiredFiles.forEach(f => {
  const exists = fs.existsSync(f);
  const size = exists ? fs.statSync(f).size : 0;
  console.log(`  [${exists ? 'PASS' : 'FAIL'}] ${path.relative(rootDir, f)} (${size} bytes)`);
  if (!exists) allPassed = false;
});

// 2. SVG Validation & ID collision check
console.log('\nTest 2: SVG self-containment, foreignObject check & ID namespace analysis:');
const svgFiles = ['hero.svg', 'about-life.svg', 'stack.svg', 'id-dashboard.svg', 'connect.svg'];
const allFoundIds = new Map();

svgFiles.forEach(file => {
  const content = fs.readFileSync(path.join(assetsDir, file), 'utf8');
  
  // Check foreignObject
  if (content.includes('foreignObject')) {
    console.log(`  [FAIL] ${file} contains disallowed foreignObject!`);
    allPassed = false;
  } else {
    console.log(`  [PASS] ${file} has zero foreignObject elements.`);
  }

  // Check external HTTP/S requests
  const externalUrls = (content.match(/https?:\/\/[^\s"'>]+/g) || []).filter(u => !u.includes('http://www.w3.org/2000/svg'));
  if (externalUrls.length > 0) {
    console.log(`  [WARN] ${file} contains external URLs:`, externalUrls);
  } else {
    console.log(`  [PASS] ${file} contains zero external network requests.`);
  }

  // Check IDs
  const idMatches = content.match(/id="([^"]+)"/g) || [];
  idMatches.forEach(m => {
    const id = m.replace(/id="|"/g, '');
    if (allFoundIds.has(id)) {
      console.log(`  [COLLISION] ID "${id}" is duplicated across ${allFoundIds.get(id)} and ${file}!`);
      allPassed = false;
    } else {
      allFoundIds.set(id, file);
    }
  });

  // Test SVG parse with Resvg
  try {
    const resvg = new Resvg(content, { fitTo: { mode: 'width', value: 850 } });
    const rendered = resvg.render();
    console.log(`  [PASS] ${file} parsed & rendered cleanly (${rendered.width}x${rendered.height}px)`);
  } catch (err) {
    console.log(`  [FAIL] ${file} failed rendering:`, err.message);
    allPassed = false;
  }
});

console.log(`\nTotal unique SVG IDs across all 5 files: ${allFoundIds.size} (No collisions found)`);

// 3. Test README.md links
console.log('\nTest 3: README.md link verification:');
const readmeContent = fs.readFileSync(path.join(outDir, 'README.md'), 'utf8');
const markdownLinks = [...readmeContent.matchAll(/\[([^\]]+)\]\(([^)]+)\)/g)];
console.log(`Found ${markdownLinks.length} links in README.md:`);
markdownLinks.forEach(([_, text, url]) => {
  console.log(`  - ${text}: ${url}`);
});

console.log(`\nOverall QA Status: ${allPassed ? 'ALL TESTS PASSED' : 'ISSUES DETECTED'}`);
